/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/icons.ts":
/*!****************************!*\
  !*** ./src/utils/icons.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateIconDataUri: () => (/* binding */ generateIconDataUri),
/* harmony export */   generateIconFiles: () => (/* binding */ generateIconFiles),
/* harmony export */   generateIconSvg: () => (/* binding */ generateIconSvg)
/* harmony export */ });
/**
 * Icon generation utilities
 */
/**
 * Generate SVG icon data URI
 */
function generateIconDataUri(size) {
    const svg = generateIconSvg(size, size);
    const encoded = encodeURIComponent(svg);
    return `data:image/svg+xml;utf8,${encoded}`;
}
/**
 * Generate the extension icon as SVG
 */
function generateIconSvg(width, height) {
    // Calculate dimensions based on size
    const padding = Math.max(2, Math.floor(width * 0.1));
    const innerWidth = width - (padding * 2);
    const innerHeight = height - (padding * 2);
    const strokeWidth = Math.max(1, Math.floor(width * 0.03));
    // Generate SVG
    return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
		<rect x="${padding}" y="${padding}" width="${innerWidth}" height="${innerHeight}" fill="#f0f0f0" stroke="#4285f4" stroke-width="${strokeWidth}" rx="${Math.floor(width * 0.1)}" />
		<text x="${width / 2}" y="${height / 2 + padding}" font-family="Arial, sans-serif" font-size="${Math.floor(innerHeight * 0.5)}" font-weight="bold" fill="#4285f4" text-anchor="middle" dominant-baseline="middle">CDD</text>
		<g transform="translate(${padding + innerWidth * 0.15}, ${padding + innerHeight * 0.65}) scale(${innerWidth * 0.007})">
			<path d="M10,20 L50,20 M10,30 L50,30 M10,40 L50,40" stroke="#fbbc05" stroke-width="${Math.floor(innerWidth * 0.15)}" stroke-linecap="round" />
		</g>
		<circle cx="${width - padding - innerWidth * 0.2}" cy="${padding + innerHeight * 0.2}" r="${innerWidth * 0.15}" fill="#34a853" />
	</svg>`;
}
/**
 * Generate and download icon files
 */
function generateIconFiles() {
    const sizes = [16, 48, 128];
    sizes.forEach(size => {
        const svg = generateIconSvg(size, size);
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        // Create download link
        const a = document.createElement('a');
        a.href = url;
        a.download = `icon${size}.svg`;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        // Clean up
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
    });
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!*******************************!*\
  !*** ./src/generate-icons.ts ***!
  \*******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/icons */ "./src/utils/icons.ts");
/**
 * This script generates SVG icons for the extension.
 * It can be run in a browser environment to generate and download icons.
 */

// Call the function when the script is loaded in a browser environment
if (typeof window !== 'undefined') {
    // Create a simple UI for generating icons
    const body = document.body;
    // Add title
    const title = document.createElement('h1');
    title.textContent = 'CommaDashDotXL Icon Generator';
    body.appendChild(title);
    // Add description
    const description = document.createElement('p');
    description.textContent = 'Click the button below to generate and download icon files for the extension.';
    body.appendChild(description);
    // Add button
    const button = document.createElement('button');
    button.textContent = 'Generate Icons';
    button.style.padding = '10px 20px';
    button.style.fontSize = '16px';
    button.style.cursor = 'pointer';
    button.onclick = _utils_icons__WEBPACK_IMPORTED_MODULE_0__.generateIconFiles;
    body.appendChild(button);
    // Show preview
    const previewTitle = document.createElement('h2');
    previewTitle.textContent = 'Icon Preview';
    body.appendChild(previewTitle);
    const previewContainer = document.createElement('div');
    previewContainer.style.display = 'flex';
    previewContainer.style.gap = '20px';
    previewContainer.style.marginTop = '20px';
    // Add previews for each size
    [16, 48, 128].forEach(size => {
        const container = document.createElement('div');
        container.innerHTML = `<div style="text-align: center; margin-bottom: 5px;">Icon ${size}px</div>`;
        container.innerHTML += (0,_utils_icons__WEBPACK_IMPORTED_MODULE_0__.generateIconSvg)(size, size);
        previewContainer.appendChild(container);
    });
    body.appendChild(previewContainer);
}

})();

/******/ })()
;
//# sourceMappingURL=generate-icons.js.map