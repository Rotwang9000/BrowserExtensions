/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/extpay/dist/ExtPay.module.js":
/*!***************************************************!*\
  !*** ./node_modules/extpay/dist/ExtPay.module.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ExtPay)
/* harmony export */ });
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);


// Sign up at https://extensionpay.com to use this library. AGPLv3 licensed.


// For running as a content script. Receive a message from the successful payments page
// and pass it on to the background page to query if the user has paid.
if (typeof window !== 'undefined') {
    window.addEventListener('message', (event) => {
        if (event.origin !== 'https://extensionpay.com') return;
        if (event.source != window) return;
        if (event.data === 'extpay-fetch-user' || event.data === 'extpay-trial-start') {
            window.postMessage(`${event.data}-received`);
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.sendMessage(event.data);
        }
    }, false);
}

function ExtPay(extension_id) {

    const HOST = `https://extensionpay.com`;
    const EXTENSION_URL = `${HOST}/extension/${extension_id}`;

    function timeout(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    async function get(key) {
        try {
            return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.storage.sync.get(key)
        } catch(e) {
            // if sync not available (like with Firefox temp addons), fall back to local
            return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.storage.local.get(key)
        }
    }
    async function set(dict) {
        try {
            return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.storage.sync.set(dict)
        } catch(e) {
            // if sync not available (like with Firefox temp addons), fall back to local
            return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.storage.local.set(dict)
        }
    }

    // ----- start configuration checks
    webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management && webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management.getSelf().then(async (ext_info) => {
        if (!ext_info.permissions.includes('storage')) {
            var permissions = ext_info.hostPermissions.concat(ext_info.permissions);
            throw `ExtPay Setup Error: please include the "storage" permission in manifest.json["permissions"] or else ExtensionPay won't work correctly.

You can copy and paste this to your manifest.json file to fix this error:

"permissions": [
    ${permissions.map(x => `"    ${x}"`).join(',\n')}${permissions.length > 0 ? ',' : ''}
    "storage"
]
`
        }

    });
    // ----- end configuration checks

    // run on "install"
    get(['extensionpay_installed_at', 'extensionpay_user']).then(async (storage) => {
        if (storage.extensionpay_installed_at) return;

        // Migration code: before v2.1 installedAt came from the server
        // so use that stored datetime instead of making a new one.
        const user = storage.extensionpay_user;
        const date = user ? user.installedAt : (new Date()).toISOString();
        await set({'extensionpay_installed_at': date});
    });

    const paid_callbacks = [];
    const trial_callbacks =  [];

    async function create_key() {
        var body = {};
        var ext_info;
        if (webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management) {
            ext_info = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management.getSelf();
        } else if (webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime) {
            ext_info = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.sendMessage('extpay-extinfo'); // ask background page for ext info
            if (!ext_info) {
                // Safari doesn't support browser.management for some reason
                const is_dev_mode = !('update_url' in webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.getManifest());
                ext_info = {installType: is_dev_mode ? 'development' : 'normal'};
            }
        } else {
            throw 'ExtPay needs to be run in a browser extension context'
        }

        if (ext_info.installType == 'development') {
            body.development = true;
        } 

        const resp = await fetch(`${EXTENSION_URL}/api/new-key`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!resp.ok) {
            throw resp.status, `${HOST}/home`
        }
        const api_key = await resp.json();
        await set({extensionpay_api_key: api_key});
        return api_key;
    }

    async function get_key() {
        const storage = await get(['extensionpay_api_key']);
        if (storage.extensionpay_api_key) {
            return storage.extensionpay_api_key;
        }
        return null;
    }

    const datetime_re = /^\d\d\d\d-\d\d-\d\dT/;

    async function fetch_user() {
        var storage = await get(['extensionpay_user', 'extensionpay_installed_at']);
        const api_key = await get_key();
        if (!api_key) {
            return {
                paid: false,
                paidAt: null,
                installedAt: storage.extensionpay_installed_at ? new Date(storage.extensionpay_installed_at) : new Date(), // sometimes this function gets called before the initial install time can be flushed to storage
                trialStartedAt: null,
            }
        }

        const resp = await fetch(`${EXTENSION_URL}/api/v2/user?api_key=${api_key}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        });
        // TODO: think harder about error states and what users will want (bad connection, server error, id not found)
        if (!resp.ok) throw 'ExtPay error while fetching user: '+(await resp.text())

        const user_data = await resp.json();

        const parsed_user = {};
        for (var [key, value] of Object.entries(user_data)) {
            if (value && value.match && value.match(datetime_re)) {
                value = new Date(value);
            }
            parsed_user[key] = value;
        }
        parsed_user.installedAt = new Date(storage.extensionpay_installed_at);
          

        if (parsed_user.paidAt) {
            if (!storage.extensionpay_user || (storage.extensionpay_user && !storage.extensionpay_user.paidAt)) {
                paid_callbacks.forEach(cb => cb(parsed_user));
            }
        }
        if (parsed_user.trialStartedAt) {
            if (!storage.extensionpay_user || (storage.extensionpay_user && !storage.extensionpay_user.trialStartedAt)) {
                trial_callbacks.forEach(cb => cb(parsed_user));
            }

        }
        await set({extensionpay_user: user_data});

        return parsed_user;
    }

    async function get_plans() {
        const resp = await fetch(`${EXTENSION_URL}/api/v2/current-plans`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-type': 'application/json',
            },
        });
        if (!resp.ok) {
            throw `ExtPay: HTTP error while getting plans. Received http code: ${resp.status}`
        }
        return await resp.json();
    }

    async function open_popup(url, width, height) {
        if (webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.windows && webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.windows.create) {
            const current_window = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.windows.getCurrent();
            // https://stackoverflow.com/a/68456858
            const left = Math.round((current_window.width - width) * 0.5 + current_window.left);
            const top = Math.round((current_window.height - height) * 0.5 + current_window.top);
            try {
                webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.windows.create({
                    url: url,
                    type: "popup",
                    focused: true,
                    width,
                    height,
                    left,
                    top
                });
            } catch(e) {
                // firefox doesn't support 'focused'
                webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.windows.create({
                    url: url,
                    type: "popup",
                    width,
                    height,
                    left,
                    top
                });
            }
        } else {
            // for opening from a content script
            // https://developer.mozilla.org/en-US/docs/Web/API/Window/open
            window.open(url, null, `toolbar=no,location=no,directories=no,status=no,menubar=no,width=${width},height=${height},left=450`);
        }
    }

    async function open_payment_page(plan_nickname) {
        var api_key = await get_key();
        if (!api_key) {
            api_key = await create_key();
        }
        let url = `${EXTENSION_URL}/choose-plan?api_key=${api_key}`;
        if (plan_nickname) {
            url = `${EXTENSION_URL}/choose-plan/${plan_nickname}?api_key=${api_key}`;
        }
        if (webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.tabs && webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.tabs.create) {
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.tabs.create({url, active: true});
        } else {
            window.open(url, '_blank');
        }
    }

    async function open_trial_page(period) {
        // let user have period string like '1 week' e.g. "start your 1 week free trial"

        var api_key = await get_key();
        if (!api_key) {
            api_key = await create_key();
        }
        var url = `${EXTENSION_URL}/trial?api_key=${api_key}`;
        if (period) {
            url += `&period=${period}`;
        }
        open_popup(url, 500, 700);
    }
    async function open_login_page() {
        var api_key = await get_key();
        if (!api_key) {
            api_key = await create_key();
        }
        const url = `${EXTENSION_URL}/reactivate?api_key=${api_key}&back=choose-plan&v2`;
        open_popup(url, 500, 800);
    }

    var polling = false;
    async function poll_user_paid() {
        // keep trying to fetch user in case stripe webhook is late
        if (polling) return;
        polling = true;
        var user = await fetch_user();
        for (var i=0; i < 2*60; ++i) {
            if (user.paidAt) {
                polling = false;
                return user;
            }
            await timeout(1000);
            user = await fetch_user();
        }
        polling = false;
    }


    
    return {
        getUser: function() {
            return fetch_user()
        },
        onPaid: {
            addListener: function(callback) {
                const content_script_template = `"content_scripts": [
                {
            "matches": ["${HOST}/*"],
            "js": ["ExtPay.js"],
            "run_at": "document_start"
        }]`;
                const manifest = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.getManifest();
                if (!manifest.content_scripts) {
                    throw `ExtPay setup error: To use the onPaid callback handler, please include ExtPay as a content script in your manifest.json. You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`
                }
                const extpay_content_script_entry = manifest.content_scripts.find(obj => {
                    // removing port number because firefox ignores content scripts with port number
                    return obj.matches.includes(HOST.replace(':3000', '')+'/*')
                });
                if (!extpay_content_script_entry) {
                    throw `ExtPay setup error: To use the onPaid callback handler, please include ExtPay as a content script in your manifest.json matching "${HOST}/*". You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`
                } else {
                    if (!extpay_content_script_entry.run_at || extpay_content_script_entry.run_at !== 'document_start') {
                        throw `ExtPay setup error: To use the onPaid callback handler, please make sure the ExtPay content script in your manifest.json runs at document start. You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`
                    }
                }

                paid_callbacks.push(callback);
            },
            // removeListener: function(callback) {
            //     // TODO
            // }
        },
        getPlans: get_plans,
        openPaymentPage: open_payment_page,
        openTrialPage: open_trial_page,
        openLoginPage: open_login_page,
        onTrialStarted: {
            addListener: function(callback) {
                trial_callbacks.push(callback);
            }
        },
        startBackground: function() {
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.onMessage.addListener(function(message, sender, send_response) {
                if (message == 'extpay-fetch-user') {
                    // Only called via extensionpay.com/extension/[extension-id]/paid -> content_script when user successfully pays.
                    // It's possible attackers could trigger this but that is basically harmless. It would just query the user.
                    poll_user_paid();
                } else if (message == 'extpay-trial-start') {
                    // no need to poll since the trial confirmation page has already set trialStartedAt
                    fetch_user(); 
                } else if (message == 'extpay-extinfo' && webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management) {
                    // get this message from content scripts which can't access browser.management
                    return webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.management.getSelf()
                } 
            });
        }
    }
}




/***/ }),

/***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.7.0 - Tue Nov 10 2020 20:24:04 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)"; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.rejection
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(extensionAPIs.runtime.lastError);
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      }); // Keep track if the deprecation warning has been logged at least once.


      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }

              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(extensionAPIs.runtime.lastError);
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      throw new Error("This script should only be loaded in a browser extension.");
    } // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./src/utils/delimiterPrompt.ts":
/*!**************************************!*\
  !*** ./src/utils/delimiterPrompt.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   promptForDelimiter: () => (/* binding */ promptForDelimiter)
/* harmony export */ });
/* harmony import */ var _formatDetector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formatDetector */ "./src/utils/formatDetector.ts");
/**
 * Utility for prompting the user to select a delimiter when we can't detect it automatically
 */

// Common delimiters with human-readable names
const DELIMITER_OPTIONS = [
    { value: ',', label: 'Comma (,)' },
    { value: '\t', label: 'Tab' },
    { value: ';', label: 'Semicolon (;)' },
    { value: '|', label: 'Pipe (|)' },
    { value: ' ', label: 'Space' }
];
/**
 * Show a modal dialog to prompt the user for a delimiter
 * @param text The text to parse
 * @param callback Function to call with the parsed data when a delimiter is selected
 */
function promptForDelimiter(text, callback) {
    // Create modal container
    const modal = document.createElement('div');
    modal.className = 'delimiter-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '1000';
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'delimiter-modal-content';
    modalContent.style.backgroundColor = '#fff';
    modalContent.style.padding = '20px';
    modalContent.style.borderRadius = '8px';
    modalContent.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
    modalContent.style.maxWidth = '500px';
    modalContent.style.width = '90%';
    // Add title
    const title = document.createElement('h3');
    title.textContent = 'Select Delimiter';
    title.style.margin = '0 0 15px 0';
    title.style.textAlign = 'center';
    modalContent.appendChild(title);
    // Add description
    const description = document.createElement('p');
    description.textContent = "We couldn't automatically detect the delimiter in your data. Please select the delimiter that separates columns in your data.";
    description.style.marginBottom = '20px';
    modalContent.appendChild(description);
    // Preview section for showing a sample
    const previewSection = document.createElement('div');
    previewSection.style.marginBottom = '20px';
    previewSection.style.borderRadius = '4px';
    previewSection.style.padding = '10px';
    previewSection.style.backgroundColor = '#f5f5f5';
    previewSection.style.maxHeight = '100px';
    previewSection.style.overflow = 'auto';
    previewSection.style.fontFamily = 'monospace';
    previewSection.style.fontSize = '12px';
    previewSection.style.whiteSpace = 'pre-wrap';
    previewSection.style.wordBreak = 'break-all';
    // Get sample text for preview
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    const sampleLines = lines.slice(0, Math.min(3, lines.length));
    previewSection.textContent = sampleLines.join('\n');
    modalContent.appendChild(previewSection);
    // Create delimiter options container
    const optionsContainer = document.createElement('div');
    optionsContainer.style.display = 'flex';
    optionsContainer.style.flexDirection = 'column';
    optionsContainer.style.gap = '10px';
    // Add each delimiter option
    DELIMITER_OPTIONS.forEach(option => {
        const optionBtn = document.createElement('button');
        optionBtn.textContent = option.label;
        optionBtn.style.padding = '10px';
        optionBtn.style.borderRadius = '4px';
        optionBtn.style.border = '1px solid #ddd';
        optionBtn.style.backgroundColor = '#f8f8f8';
        optionBtn.style.cursor = 'pointer';
        optionBtn.style.transition = 'all 0.2s';
        optionBtn.addEventListener('mouseover', () => {
            optionBtn.style.backgroundColor = '#e0e0e0';
        });
        optionBtn.addEventListener('mouseout', () => {
            optionBtn.style.backgroundColor = '#f8f8f8';
        });
        optionBtn.addEventListener('click', () => {
            // Parse the data with the selected delimiter
            const parsedData = parseWithUserSelectedDelimiter(text, option.value);
            // Close the modal
            modal.remove();
            // Call the callback with the parsed data
            callback(parsedData);
        });
        optionsContainer.appendChild(optionBtn);
    });
    // Add custom delimiter option
    const customContainer = document.createElement('div');
    customContainer.style.marginTop = '10px';
    customContainer.style.display = 'flex';
    customContainer.style.alignItems = 'center';
    customContainer.style.gap = '10px';
    const customLabel = document.createElement('label');
    customLabel.textContent = 'Custom:';
    customLabel.style.flexShrink = '0';
    const customInput = document.createElement('input');
    customInput.type = 'text';
    customInput.maxLength = 1;
    customInput.style.width = '40px';
    customInput.style.padding = '5px';
    customInput.style.borderRadius = '4px';
    customInput.style.border = '1px solid #ddd';
    customInput.style.textAlign = 'center';
    const customButton = document.createElement('button');
    customButton.textContent = 'Apply';
    customButton.style.padding = '5px 10px';
    customButton.style.borderRadius = '4px';
    customButton.style.border = '1px solid #ddd';
    customButton.style.backgroundColor = '#f8f8f8';
    customButton.style.cursor = 'pointer';
    customButton.addEventListener('click', () => {
        const customDelimiter = customInput.value;
        if (customDelimiter.length === 0) {
            return;
        }
        // Parse with custom delimiter
        const parsedData = parseWithUserSelectedDelimiter(text, customDelimiter);
        // Close the modal
        modal.remove();
        // Call the callback with the parsed data
        callback(parsedData);
    });
    // Allow pressing Enter in the custom input field
    customInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            customButton.click();
        }
    });
    customContainer.appendChild(customLabel);
    customContainer.appendChild(customInput);
    customContainer.appendChild(customButton);
    // Cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.marginTop = '20px';
    cancelBtn.style.padding = '10px';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.border = '1px solid #ddd';
    cancelBtn.style.backgroundColor = '#f5f5f5';
    cancelBtn.style.color = '#666';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.addEventListener('click', () => {
        modal.remove();
        callback(null);
    });
    // Add all elements to the modal
    modalContent.appendChild(optionsContainer);
    modalContent.appendChild(customContainer);
    modalContent.appendChild(cancelBtn);
    modal.appendChild(modalContent);
    // Add to document body
    document.body.appendChild(modal);
    // Close modal when clicking outside content
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            callback(null);
        }
    });
}
/**
 * Parse data with a user-selected delimiter
 * @param text The text to parse
 * @param delimiter The delimiter to use
 * @returns The parsed data
 */
function parseWithUserSelectedDelimiter(text, delimiter) {
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) {
        return { headers: [], rows: [], columns: [], hasHeaders: false };
    }
    // Special case for single values with no actual delimiter in content
    if (lines.length === 1 && !lines[0].includes(delimiter)) {
        const singleValue = lines[0].trim();
        // Create a simple single-cell table
        const headers = ['Value'];
        const rows = [[singleValue]];
        // Analyze for number or date format
        let valueType = 'text';
        let formatKey = null;
        // Check if it's a number
        for (const format of _formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS) {
            if (format.regex.test(singleValue)) {
                valueType = 'number';
                formatKey = format.key;
                break;
            }
        }
        // If not a number, check if it's a date
        if (valueType === 'text') {
            for (const format of _formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS) {
                if (format.regex.test(singleValue)) {
                    valueType = 'date';
                    formatKey = format.key;
                    break;
                }
            }
        }
        // Create column info with the detected format if any
        const columns = (0,_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(rows, headers);
        return {
            headers,
            rows,
            columns,
            hasHeaders: false
        };
    }
    // Parse rows using the selected delimiter
    const rawRows = lines.map(line => line.split(delimiter));
    // Check if the first row appears to be headers
    const hasHeaders = rawRows.length > 1 &&
        rawRows[0].length === rawRows[1].length &&
        // Headers typically don't have the same data type as the rows
        rawRows[0].some((header, i) => rawRows.slice(1).some(row => {
            const isHeaderNumeric = !isNaN(Number(header));
            const isCellNumeric = i < row.length && !isNaN(Number(row[i]));
            return isHeaderNumeric !== isCellNumeric;
        }));
    const headers = hasHeaders ? rawRows[0] : rawRows[0].map((_, index) => `Column ${index + 1}`);
    const rows = hasHeaders ? rawRows.slice(1) : rawRows;
    // Analyze columns for possible formats
    const columns = (0,_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(rows, headers);
    return {
        headers,
        rows,
        columns,
        hasHeaders
    };
}


/***/ }),

/***/ "./src/utils/delimiters.ts":
/*!*********************************!*\
  !*** ./src/utils/delimiters.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   COMMON_DELIMITERS: () => (/* binding */ COMMON_DELIMITERS),
/* harmony export */   QUOTE_CHARS: () => (/* binding */ QUOTE_CHARS),
/* harmony export */   detectDelimiter: () => (/* binding */ detectDelimiter),
/* harmony export */   detectQuoteCharacter: () => (/* binding */ detectQuoteCharacter),
/* harmony export */   parseDelimitedText: () => (/* binding */ parseDelimitedText),
/* harmony export */   splitLineRespectingQuotes: () => (/* binding */ splitLineRespectingQuotes)
/* harmony export */ });
/**
 * Utilities for detecting and handling delimiters in tabular data
 */
// List of common delimiters to check
const COMMON_DELIMITERS = [',', '\t', ';', '|', ' '];
// Potential quote characters
const QUOTE_CHARS = ['"', "'"];
/**
 * Detect the delimiter used in tabular data
 * @param text The text to analyze for delimiters
 * @returns The detected delimiter or null if none could be determined with confidence
 */
function detectDelimiter(text) {
    if (!text || text.trim().length === 0) {
        return null;
    }
    // Split into lines and filter out empty lines
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) {
        return null;
    }
    // Try common delimiters first - this is faster and handles most cases
    const commonDelimiter = detectCommonDelimiter(lines);
    if (commonDelimiter) {
        return commonDelimiter;
    }
    // If no common delimiter was found, try a more exhaustive approach
    return detectCustomDelimiter(lines);
}
/**
 * Detect if the text uses any common delimiter
 * @param lines Array of text lines to analyze
 * @returns The detected common delimiter or null if none found
 */
function detectCommonDelimiter(lines) {
    // Count delimiters in each line
    const delimiterCounts = {};
    // Initialize counts
    COMMON_DELIMITERS.forEach(delimiter => {
        delimiterCounts[delimiter] = [];
    });
    // Count occurrences of each delimiter in each line
    lines.slice(0, Math.min(lines.length, 10)).forEach(line => {
        COMMON_DELIMITERS.forEach(delimiter => {
            // Handle special case for tab which needs regex
            if (delimiter === '\t') {
                delimiterCounts[delimiter].push((line.match(/\t/g) || []).length);
            }
            else {
                delimiterCounts[delimiter].push(line.split(delimiter).length - 1);
            }
        });
    });
    // Score each delimiter based on consistency and frequency
    const delimiterScores = {};
    COMMON_DELIMITERS.forEach(delimiter => {
        const counts = delimiterCounts[delimiter];
        // Skip if no occurrences
        if (counts.every(count => count === 0)) {
            delimiterScores[delimiter] = 0;
            return;
        }
        // Calculate average count
        const avgCount = counts.reduce((sum, count) => sum + count, 0) / counts.length;
        // Calculate consistency (how close each count is to the average)
        const consistency = counts.reduce((sum, count) => {
            return sum + (1 - Math.abs(count - avgCount) / (avgCount || 1));
        }, 0) / counts.length;
        // Final score combines average count and consistency
        delimiterScores[delimiter] = avgCount * consistency;
    });
    // Find the delimiter with the highest score
    let bestDelimiter = null;
    let bestScore = 0;
    for (const delimiter of COMMON_DELIMITERS) {
        const score = delimiterScores[delimiter];
        if (score > bestScore) {
            bestScore = score;
            bestDelimiter = delimiter;
        }
    }
    // Only return the delimiter if the score is above a threshold
    // and most lines have at least one occurrence
    if (bestScore > 0.5) {
        const counts = delimiterCounts[bestDelimiter];
        const linesWithDelimiter = counts.filter(count => count > 0).length;
        if (linesWithDelimiter / lines.length > 0.7) {
            return bestDelimiter;
        }
    }
    return null;
}
/**
 * Try to detect a non-standard delimiter by analyzing all non-alphanumeric characters
 * @param lines Array of text lines to analyze
 * @returns The detected custom delimiter or null if none found
 */
function detectCustomDelimiter(lines) {
    // Get all potential delimiter characters (non-alphanumeric) from the text
    const potentialDelimiters = new Set();
    const sampleLines = lines.slice(0, Math.min(lines.length, 10));
    // Find all non-alphanumeric characters that appear in the text
    sampleLines.forEach(line => {
        for (let i = 0; i < line.length; i++) {
            const char = line.charAt(i);
            // Skip alphanumeric, whitespace except space, and already checked common delimiters
            if (/^[a-zA-Z0-9\r\n\t]$/.test(char) || COMMON_DELIMITERS.includes(char)) {
                continue;
            }
            potentialDelimiters.add(char);
        }
    });
    if (potentialDelimiters.size === 0) {
        return null;
    }
    // Count occurrences and check consistency like we did for common delimiters
    const delimiterCounts = {};
    potentialDelimiters.forEach(delimiter => {
        delimiterCounts[delimiter] = [];
    });
    sampleLines.forEach(line => {
        potentialDelimiters.forEach(delimiter => {
            // Use a regex-safe delimiter
            const escapedDelimiter = delimiter.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(escapedDelimiter, 'g');
            delimiterCounts[delimiter].push((line.match(regex) || []).length);
        });
    });
    // Calculate scores
    const delimiterScores = {};
    potentialDelimiters.forEach(delimiter => {
        const counts = delimiterCounts[delimiter];
        // Skip if no occurrences or inconsistent
        if (counts.every(count => count === 0)) {
            delimiterScores[delimiter] = 0;
            return;
        }
        // Calculate average count
        const avgCount = counts.reduce((sum, count) => sum + count, 0) / counts.length;
        // Calculate consistency
        const consistency = counts.reduce((sum, count) => {
            return sum + (1 - Math.abs(count - avgCount) / (avgCount || 1));
        }, 0) / counts.length;
        // Final score combines average count and consistency
        delimiterScores[delimiter] = avgCount * consistency;
    });
    // Find the best delimiter
    let bestDelimiter = null;
    let bestScore = 0;
    for (const delimiter of potentialDelimiters) {
        const score = delimiterScores[delimiter];
        if (score > bestScore) {
            bestScore = score;
            bestDelimiter = delimiter;
        }
    }
    // Only return if confident
    if (bestScore > 0.5) {
        return bestDelimiter;
    }
    return null;
}
/**
 * Detect if the data uses text qualifiers (quotes)
 * @param text The text to analyze
 * @param delimiter The delimiter being used
 * @returns The detected quote character or null if none found
 */
function detectQuoteCharacter(text, delimiter) {
    if (!text || !delimiter) {
        return null;
    }
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) {
        return null;
    }
    // Check each potential quote character
    for (const quoteChar of QUOTE_CHARS) {
        // Count how many fields are enclosed in this quote character
        let quotedFieldCount = 0;
        let totalFieldCount = 0;
        // Check a sample of lines
        const sampleLines = lines.slice(0, Math.min(lines.length, 5));
        for (const line of sampleLines) {
            // Basic pattern: quote at start and end of field
            const quotePattern = new RegExp(`${quoteChar}[^${quoteChar}]*${quoteChar}`, 'g');
            const matches = line.match(quotePattern) || [];
            quotedFieldCount += matches.length;
            // Count total fields using the delimiter
            totalFieldCount += line.split(delimiter).length;
        }
        // If a significant portion of fields use quotes, return this quote character
        if (quotedFieldCount > 0 && quotedFieldCount / totalFieldCount > 0.2) {
            return quoteChar;
        }
    }
    return null;
}
/**
 * Split a line into fields respecting quotes
 * @param line The line to split
 * @param delimiter The delimiter character
 * @param quoteChar The quote character (if any)
 * @returns Array of fields
 */
function splitLineRespectingQuotes(line, delimiter, quoteChar) {
    if (!quoteChar) {
        return line.split(delimiter);
    }
    const fields = [];
    let currentField = '';
    let inQuote = false;
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        // Handle quote character
        if (char === quoteChar) {
            // If we see two quotes in a row inside a quoted field, treat it as an escaped quote
            if (inQuote && i + 1 < line.length && line[i + 1] === quoteChar) {
                currentField += quoteChar;
                i++; // Skip the next quote
            }
            else {
                // Toggle quote state
                inQuote = !inQuote;
            }
        }
        // Handle delimiter (only if not in quotes)
        else if (char === delimiter && !inQuote) {
            fields.push(currentField);
            currentField = '';
        }
        // All other characters
        else {
            currentField += char;
        }
    }
    // Add the last field
    fields.push(currentField);
    // Clean up quotes from the fields if needed
    return fields.map(field => {
        // Remove surrounding quotes
        if (quoteChar && field.startsWith(quoteChar) && field.endsWith(quoteChar)) {
            return field.substring(1, field.length - 1);
        }
        return field;
    });
}
/**
 * Parse tabular data with detected delimiters and quotes
 * @param text The text to parse
 * @returns Array of rows, each containing array of fields
 */
function parseDelimitedText(text) {
    if (!text || text.trim().length === 0) {
        return [];
    }
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) {
        return [];
    }
    // Detect delimiter and quote character
    const delimiter = detectDelimiter(text) || ','; // Default to comma if can't detect
    const quoteChar = detectQuoteCharacter(text, delimiter);
    // Parse each line
    return lines.map(line => splitLineRespectingQuotes(line, delimiter, quoteChar));
}


/***/ }),

/***/ "./src/utils/extPayHandler.ts":
/*!************************************!*\
  !*** ./src/utils/extPayHandler.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkUserStatus: () => (/* binding */ checkUserStatus),
/* harmony export */   openPaymentPage: () => (/* binding */ openPaymentPage),
/* harmony export */   startExtPayBackground: () => (/* binding */ startExtPayBackground)
/* harmony export */ });
/* harmony import */ var extpay__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! extpay */ "./node_modules/extpay/dist/ExtPay.module.js");

// Initialize ExtPay with the extension ID
const extpay = (0,extpay__WEBPACK_IMPORTED_MODULE_0__["default"])('commadashdotxl');
// Start background processes - this should be called in the background script
function startExtPayBackground() {
    extpay.startBackground();
}
// Check if user has paid
async function checkUserStatus() {
    try {
        const user = await extpay.getUser();
        return {
            paid: user.paid,
            subscriptionStatus: user.subscriptionStatus,
        };
    }
    catch (error) {
        console.error('Error checking ExtPay user status:', error);
        return {
            paid: false,
            subscriptionStatus: null,
        };
    }
}
// Open the payment page
function openPaymentPage() {
    extpay.openPaymentPage();
}


/***/ }),

/***/ "./src/utils/formatDetector.ts":
/*!*************************************!*\
  !*** ./src/utils/formatDetector.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DATE_FORMATS: () => (/* binding */ DATE_FORMATS),
/* harmony export */   NUMBER_FORMATS: () => (/* binding */ NUMBER_FORMATS),
/* harmony export */   analyzeColumns: () => (/* binding */ analyzeColumns),
/* harmony export */   checkForPotentialYears: () => (/* binding */ checkForPotentialYears),
/* harmony export */   convertDate: () => (/* binding */ convertDate),
/* harmony export */   convertNumber: () => (/* binding */ convertNumber),
/* harmony export */   parseTabularData: () => (/* binding */ parseTabularData)
/* harmony export */ });
/* harmony import */ var _delimiters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./delimiters */ "./src/utils/delimiters.ts");
/* harmony import */ var _delimiterPrompt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./delimiterPrompt */ "./src/utils/delimiterPrompt.ts");
/**
 * Date and number format detection and conversion utilities
 */


// Date format patterns
const DATE_FORMATS = [
    { key: 'MM/DD/YYYY', name: 'US (MM/DD/YYYY)', regex: /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/(\d{4}|\d{2})$/ },
    { key: 'DD/MM/YYYY', name: 'UK/EU (DD/MM/YYYY)', regex: /^(0?[1-9]|[12][0-9]|3[01])\/(0?[1-9]|1[0-2])\/(\d{4}|\d{2})$/ },
    { key: 'YYYY/MM/DD', name: 'ISO (YYYY/MM/DD)', regex: /^(\d{4}|\d{2})\/(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])$/ },
    { key: 'MM-DD-YYYY', name: 'US with dashes (MM-DD-YYYY)', regex: /^(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01])-(\d{4}|\d{2})$/ },
    { key: 'DD-MM-YYYY', name: 'UK/EU with dashes (DD-MM-YYYY)', regex: /^(0?[1-9]|[12][0-9]|3[01])-(0?[1-9]|1[0-2])-(\d{4}|\d{2})$/ },
    { key: 'YYYY-MM-DD', name: 'ISO with dashes (YYYY-MM-DD)', regex: /^(\d{4}|\d{2})-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01])$/ },
    { key: 'DD.MM.YYYY', name: 'European (DD.MM.YYYY)', regex: /^(0?[1-9]|[12][0-9]|3[01])\.(0?[1-9]|1[0-2])\.(\d{4}|\d{2})$/ },
    { key: 'YYYY.MM.DD', name: 'ISO with dots (YYYY.MM.DD)', regex: /^(\d{4}|\d{2})\.(0?[1-9]|1[0-2])\.(0?[1-9]|[12][0-9]|3[01])$/ },
    { key: 'MMMM DD, YYYY', name: 'Long (Month DD, YYYY)', regex: /^([A-Za-z]+)\s+(0?[1-9]|[12][0-9]|3[01]),\s+(\d{4})$/ },
    { key: 'DD MMMM YYYY', name: 'Long (DD Month YYYY)', regex: /^(0?[1-9]|[12][0-9]|3[01])\s+([A-Za-z]+)\s+(\d{4})$/ },
    { key: 'MMM DD', name: 'Abbreviated Month (MMM DD)', regex: /^([A-Za-z]{3})\s+(0?[1-9]|[12][0-9]|3[01])$/ },
    { key: 'MMM DD YYYY', name: 'Abbreviated Month with Year (MMM DD YYYY)', regex: /^([A-Za-z]{3})\s+(0?[1-9]|[12][0-9]|3[01])(?:\s+(\d{4}))?$/ },
    { key: 'DD MMM', name: 'Day with Abbreviated Month (DD MMM)', regex: /^(0?[1-9]|[12][0-9]|3[01])\s+([A-Za-z]{3})$/ },
    { key: 'DD MMM YYYY', name: 'Day with Abbreviated Month and Year (DD MMM YYYY)', regex: /^(0?[1-9]|[12][0-9]|3[01])\s+([A-Za-z]{3})(?:\s+(\d{4}))?$/ },
    { key: 'YYYY MMM', name: 'Year with Abbreviated Month (YYYY MMM)', regex: /^(\d{4})\s+([A-Za-z]{3})$/ },
    { key: 'YYYY', name: 'Year Only (YYYY)', regex: /^(\d{4})$/ },
    { key: 'unix_timestamp', name: 'Timestamp', regex: /^(\d{10,13})$/ },
];
// Number format patterns
const NUMBER_FORMATS = [
    { key: 'comma_decimal_point', name: 'Comma as thousands separator, point as decimal (1,234.56)', regex: /^-?(\d{1,3}(,\d{3})*(\.\d+)?)$/ },
    { key: 'point_decimal_comma', name: 'Point as thousands separator, comma as decimal (1.234,56)', regex: /^-?(\d{1,3}(\.\d{3})*(,\d+)?)$/ },
    { key: 'space_decimal_point', name: 'Space as thousands separator, point as decimal (1 234.56)', regex: /^-?(\d{1,3}(\s\d{3})*(\.\d+)?)$/ },
    { key: 'space_decimal_comma', name: 'Space as thousands separator, comma as decimal (1 234,56)', regex: /^-?(\d{1,3}(\s\d{3})*(,\d+)?)$/ },
    { key: 'no_separator_decimal_point', name: 'No separator, point as decimal (1234.56)', regex: /^-?(\d+\.\d+)$/ },
    { key: 'no_separator_decimal_comma', name: 'No separator, comma as decimal (1234,56)', regex: /^-?(\d+,\d+)$/ },
    { key: 'integer', name: 'Integer (1234)', regex: /^-?\d+$/ },
];
// Month abbreviations to full month name mapping
const MONTH_ABBR_MAP = {
    'JAN': 0, 'FEB': 1, 'MAR': 2, 'APR': 3, 'MAY': 4, 'JUN': 5,
    'JUL': 6, 'AUG': 7, 'SEP': 8, 'OCT': 9, 'NOV': 10, 'DEC': 11
};
// Full month names array
const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
// Month abbreviations array
const MONTH_ABBRS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
/**
 * Parse tabular data (CSV, TSV, etc.) with optional prompt for delimiter
 * @param text The text to parse
 * @param promptOnFailure Whether to prompt the user for a delimiter if detection fails
 * @param callback Optional callback function for when parsing completes (used with promptOnFailure)
 * @param isSpreadsheetData Optional flag indicating the data comes from a spreadsheet (via HTML detection)
 * @returns The parsed data or null if parsing fails and promptOnFailure is false
 */
function parseTabularData(text, promptOnFailure = false, callback, isSpreadsheetData = false) {
    // Early return for empty text
    if (!text || text.trim().length === 0) {
        return { headers: [], rows: [], columns: [], hasHeaders: false };
    }
    const trimmedText = text.trim();
    // Special handling for single values (numbers, dates)
    if (!trimmedText.includes('\n') && !trimmedText.includes(',') && !trimmedText.includes('\t') && !trimmedText.includes(';') && !trimmedText.includes('|')) {
        // Check if this is a single number or date
        const singleValue = trimmedText.trim();
        let valueType = 'text';
        let formatKey = null;
        // Check if it's a number
        for (const format of NUMBER_FORMATS) {
            if (format.regex.test(singleValue)) {
                valueType = 'number';
                formatKey = format.key;
                break;
            }
        }
        // If not a number, check if it's a date
        if (valueType === 'text') {
            for (const format of DATE_FORMATS) {
                if (format.regex.test(singleValue)) {
                    valueType = 'date';
                    formatKey = format.key;
                    break;
                }
            }
        }
        // Create a single cell "table" with one header and one row
        const headers = ['Value'];
        const rows = [[singleValue]];
        // Create column info with the detected format if any
        const columns = [{
                index: 0,
                possibleFormats: formatKey ? [{
                        isDetected: true,
                        confidence: 1.0,
                        formatKey,
                        formatName: valueType === 'number'
                            ? NUMBER_FORMATS.find(f => f.key === formatKey)?.name || formatKey
                            : DATE_FORMATS.find(f => f.key === formatKey)?.name || formatKey
                    }] : [],
                selectedFormat: formatKey,
                targetFormat: null,
                mightContainYears: valueType === 'date' && formatKey === 'YYYY'
            }];
        const result = {
            headers,
            rows,
            columns,
            hasHeaders: false
        };
        console.log(`Parsed single ${valueType} value successfully`);
        if (callback)
            callback(result);
        return result;
    }
    // First check if we're explicitly told this is NOT spreadsheet data (test cases)
    // This check should take precedence over all other heuristics
    const isExplicitlyNotSpreadsheet = isSpreadsheetData === false; // Only true when explicitly set to false
    // For test JSON parsing, check if it looks like JSON
    if (isExplicitlyNotSpreadsheet) {
        const mightBeJson = (
        // Must start with { or [ and end with } or ]
        (trimmedText.startsWith('[') && trimmedText.endsWith(']')) ||
            (trimmedText.startsWith('{') && trimmedText.endsWith('}')));
        if (mightBeJson) {
            try {
                const jsonData = JSON.parse(trimmedText);
                // Handle array of objects (standard format)
                if (Array.isArray(jsonData) && jsonData.length > 0 && typeof jsonData[0] === 'object' && !Array.isArray(jsonData[0])) {
                    // Get headers from the first object's keys
                    const headers = Object.keys(jsonData[0]);
                    // Check if all items have similar structure
                    const allItemsValid = jsonData.every(item => typeof item === 'object' &&
                        item !== null &&
                        // Ensure each item has at least some of the same keys
                        headers.some(header => header in item));
                    if (!allItemsValid) {
                        throw new Error('Inconsistent JSON structure');
                    }
                    // Convert JSON to tabular format
                    const rows = jsonData.map(item => headers.map(header => {
                        const value = item[header];
                        // Convert values to strings, handling undefined/null
                        if (value === undefined || value === null) {
                            return '';
                        }
                        else if (typeof value === 'object') {
                            // Stringify nested objects/arrays
                            return JSON.stringify(value);
                        }
                        else {
                            return String(value);
                        }
                    }));
                    // Analyze columns for possible formats
                    const columns = analyzeColumns(rows, headers);
                    const result = {
                        headers,
                        rows,
                        columns,
                        hasHeaders: true
                    };
                    console.log('Parsed JSON array of objects successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
                // Handle array of arrays format
                if (Array.isArray(jsonData) && jsonData.length > 0 && Array.isArray(jsonData[0])) {
                    // Assume first row is headers if all elements are strings or primitive values
                    const hasHeaders = jsonData[0].every(item => typeof item === 'string' ||
                        typeof item === 'number' ||
                        typeof item === 'boolean' ||
                        item === null);
                    const headers = hasHeaders
                        ? jsonData[0].map(item => item === null ? '' : String(item))
                        : jsonData[0].map((_, i) => `Column ${i + 1}`);
                    const dataRows = hasHeaders ? jsonData.slice(1) : jsonData;
                    // Convert all values to strings
                    const stringRows = dataRows.map(row => Array.isArray(row) ? row.map(cell => {
                        if (cell === null || cell === undefined) {
                            return '';
                        }
                        else if (typeof cell === 'object') {
                            return JSON.stringify(cell);
                        }
                        else {
                            return String(cell);
                        }
                    }) : []);
                    // Filter out empty rows
                    const filteredRows = stringRows.filter(row => row.length > 0);
                    // Analyze columns for possible formats
                    const columns = analyzeColumns(filteredRows, headers);
                    const result = {
                        headers,
                        rows: filteredRows,
                        columns,
                        hasHeaders
                    };
                    console.log('Parsed JSON array of arrays successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
                // Handle single object (convert to 2-row table)
                if (!Array.isArray(jsonData) && typeof jsonData === 'object' && jsonData !== null) {
                    const headers = Object.keys(jsonData);
                    // Create a single row with the object values
                    const values = headers.map(key => {
                        const value = jsonData[key];
                        if (value === null || value === undefined) {
                            return '';
                        }
                        else if (typeof value === 'object') {
                            return JSON.stringify(value);
                        }
                        else {
                            return String(value);
                        }
                    });
                    const rows = [values];
                    const columns = analyzeColumns(rows, headers);
                    const result = {
                        headers,
                        rows,
                        columns,
                        hasHeaders: true
                    };
                    console.log('Parsed single JSON object successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
            }
            catch (error) {
                // For explicit test cases, we want better diagnostics
                console.error('JSON parsing error in test case:', error);
                // Continue with normal parsing as fallback
            }
        }
    }
    // Now handle normal cases - check for tabs and other delimiters
    // Special handling for tab-delimited data as it's common in spreadsheet data
    const containsTabs = text.includes('\t');
    const isLikelyTabularData = containsTabs && text.split('\n').length > 1;
    // If the data contains tabs and has multiple lines, it's likely spreadsheet data
    // But don't override an explicit isSpreadsheetData flag if already true
    if (isLikelyTabularData && !isSpreadsheetData) {
        // Only treat as spreadsheet data if it has a typical tab-delimited structure
        const lines = text.split('\n').slice(0, 3); // Just check first few lines
        // Check if more than half of the lines contain tabs and the tabs are roughly in the same positions
        let tabPositions = new Set();
        for (const line of lines) {
            for (let i = 0; i < line.length; i++) {
                if (line[i] === '\t') {
                    tabPositions.add(i);
                }
            }
        }
        // If it has a consistent tabular structure with multiple tab separators,
        // then it's likely spreadsheet data
        if (tabPositions.size >= 2) {
            isSpreadsheetData = true;
        }
    }
    // For normal non-test cases, check if the data might be JSON
    // Only do this if we haven't already determined it's spreadsheet data
    if (!isSpreadsheetData) {
        const mightBeJson = (
        // Must start with { or [ and end with } or ]
        (trimmedText.startsWith('[') && trimmedText.endsWith(']')) ||
            (trimmedText.startsWith('{') && trimmedText.endsWith('}')));
        // Only try JSON parsing if it looks like JSON based on additional heuristics
        const shouldAttemptJsonParsing = mightBeJson && (
        // Additional checks to ensure it's likely JSON
        trimmedText.includes('":"') || // Contains key-value pairs
            trimmedText.includes('":') || // Contains keys with colons
            trimmedText.includes(',"') || // Contains commas followed by quotes (common in JSON arrays)
            /\[\s*\{/.test(trimmedText) || // Contains [{ pattern (array of objects)
            /\[\s*\[/.test(trimmedText) // Contains [[ pattern (array of arrays)
        );
        if (shouldAttemptJsonParsing) {
            try {
                const jsonData = JSON.parse(trimmedText);
                // Rest of JSON parsing code as before
                // Handle array of objects (standard format)
                if (Array.isArray(jsonData) && jsonData.length > 0 && typeof jsonData[0] === 'object' && !Array.isArray(jsonData[0])) {
                    // ... [Existing JSON array of objects parsing] ...
                    // Get headers from the first object's keys
                    const headers = Object.keys(jsonData[0]);
                    // Check if all items have similar structure
                    const allItemsValid = jsonData.every(item => typeof item === 'object' &&
                        item !== null &&
                        // Ensure each item has at least some of the same keys
                        headers.some(header => header in item));
                    if (!allItemsValid) {
                        throw new Error('Inconsistent JSON structure');
                    }
                    // Convert JSON to tabular format
                    const rows = jsonData.map(item => headers.map(header => {
                        const value = item[header];
                        // Convert values to strings, handling undefined/null
                        if (value === undefined || value === null) {
                            return '';
                        }
                        else if (typeof value === 'object') {
                            // Stringify nested objects/arrays
                            return JSON.stringify(value);
                        }
                        else {
                            return String(value);
                        }
                    }));
                    // Analyze columns for possible formats
                    const columns = analyzeColumns(rows, headers);
                    const result = {
                        headers,
                        rows,
                        columns,
                        hasHeaders: true
                    };
                    console.log('Parsed JSON array of objects successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
                // Handle array of arrays format
                if (Array.isArray(jsonData) && jsonData.length > 0 && Array.isArray(jsonData[0])) {
                    const hasHeaders = jsonData[0].every(item => typeof item === 'string' ||
                        typeof item === 'number' ||
                        typeof item === 'boolean' ||
                        item === null);
                    const headers = hasHeaders
                        ? jsonData[0].map(item => item === null ? '' : String(item))
                        : jsonData[0].map((_, i) => `Column ${i + 1}`);
                    const dataRows = hasHeaders ? jsonData.slice(1) : jsonData;
                    // Convert all values to strings
                    const stringRows = dataRows.map(row => Array.isArray(row) ? row.map(cell => {
                        if (cell === null || cell === undefined) {
                            return '';
                        }
                        else if (typeof cell === 'object') {
                            return JSON.stringify(cell);
                        }
                        else {
                            return String(cell);
                        }
                    }) : []);
                    // Filter out empty rows
                    const filteredRows = stringRows.filter(row => row.length > 0);
                    // Analyze columns for possible formats
                    const columns = analyzeColumns(filteredRows, headers);
                    const result = {
                        headers,
                        rows: filteredRows,
                        columns,
                        hasHeaders
                    };
                    console.log('Parsed JSON array of arrays successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
                // Handle single object (convert to 2-row table)
                if (!Array.isArray(jsonData) && typeof jsonData === 'object' && jsonData !== null) {
                    const headers = Object.keys(jsonData);
                    // Create a single row with the object values
                    const values = headers.map(key => {
                        const value = jsonData[key];
                        if (value === null || value === undefined) {
                            return '';
                        }
                        else if (typeof value === 'object') {
                            return JSON.stringify(value);
                        }
                        else {
                            return String(value);
                        }
                    });
                    const rows = [values];
                    const columns = analyzeColumns(rows, headers);
                    const result = {
                        headers,
                        rows,
                        columns,
                        hasHeaders: true
                    };
                    console.log('Parsed single JSON object successfully');
                    if (callback)
                        callback(result);
                    return result;
                }
            }
            catch (error) {
                // If JSON parsing fails, continue with regular CSV parsing
                console.warn('JSON parsing attempt failed, continuing with CSV parsing:', error);
            }
        }
    }
    // Split into lines and filter out empty lines
    const lines = trimmedText.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) {
        return { headers: [], rows: [], columns: [], hasHeaders: false };
    }
    // Special handling for tab-delimited data as it's the most problematic
    if (containsTabs) {
        const result = parseTabData(lines);
        console.log('Parsed tab-delimited data successfully');
        if (callback)
            callback(result);
        return result;
    }
    // For other formats, use the robust delimiter detection
    // Detect delimiter with our new utility
    const delimiter = (0,_delimiters__WEBPACK_IMPORTED_MODULE_0__.detectDelimiter)(text);
    if (!delimiter) {
        // If we can't detect a delimiter and promptOnFailure is true, prompt the user
        if (promptOnFailure && callback) {
            // This will call the callback with the parsed data once the user selects a delimiter
            (0,_delimiterPrompt__WEBPACK_IMPORTED_MODULE_1__.promptForDelimiter)(text, callback);
            return null;
        }
        // If prompting is disabled or no callback is provided, use fallback
        const fallbackResult = parseWithFallbackDelimiter(text);
        console.log('Used fallback delimiter detection');
        if (callback)
            callback(fallbackResult);
        return fallbackResult;
    }
    // Detect if the data uses quotes
    const quoteChar = (0,_delimiters__WEBPACK_IMPORTED_MODULE_0__.detectQuoteCharacter)(text, delimiter);
    // Parse rows respecting quotes
    const rawRows = lines.map(line => (0,_delimiters__WEBPACK_IMPORTED_MODULE_0__.splitLineRespectingQuotes)(line, delimiter, quoteChar));
    // Determine if the first row is headers
    const hasHeaders = detectHeaders(rawRows);
    const headers = hasHeaders ? rawRows[0] : rawRows[0].map((_, index) => `Column ${index + 1}`);
    const rows = hasHeaders ? rawRows.slice(1) : rawRows;
    // Analyze columns for possible formats
    const columns = analyzeColumns(rows, headers);
    const result = {
        headers,
        rows,
        columns,
        hasHeaders
    };
    console.log(`Parsed delimited data successfully using "${delimiter}" as delimiter`);
    if (callback)
        callback(result);
    return result;
}
/**
 * Fallback parser for when we can't detect a delimiter with confidence
 * Uses simple heuristics to find a working delimiter
 */
function parseWithFallbackDelimiter(text) {
    // Try each common delimiter in order
    const commonDelimiters = [',', ';', '\t', '|'];
    // Count columns for each delimiter and pick the one with most consistent columns
    const delimiterScores = {};
    const lines = text.trim().split(/\r?\n/).filter(line => line.trim().length > 0);
    for (const delimiter of commonDelimiters) {
        const columnCounts = lines.slice(0, Math.min(lines.length, 10))
            .map(line => line.split(delimiter).length);
        // Skip if no delimiter found
        if (columnCounts.every(count => count <= 1)) {
            delimiterScores[delimiter] = 0;
            continue;
        }
        // Calculate consistency of column counts
        const avgColumns = columnCounts.reduce((sum, count) => sum + count, 0) / columnCounts.length;
        const consistency = columnCounts.reduce((sum, count) => {
            return sum + (1 - Math.abs(count - avgColumns) / avgColumns);
        }, 0) / columnCounts.length;
        delimiterScores[delimiter] = consistency * avgColumns;
    }
    // Find best delimiter
    let bestDelimiter = ','; // Default to comma
    let bestScore = 0;
    for (const delimiter of commonDelimiters) {
        if (delimiterScores[delimiter] > bestScore) {
            bestScore = delimiterScores[delimiter];
            bestDelimiter = delimiter;
        }
    }
    // Parse using the best delimiter
    const rawRows = lines.map(line => line.split(bestDelimiter));
    // Determine if the first row is headers
    const hasHeaders = detectHeaders(rawRows);
    const headers = hasHeaders ? rawRows[0] : rawRows[0].map((_, index) => `Column ${index + 1}`);
    const rows = hasHeaders ? rawRows.slice(1) : rawRows;
    // Analyze columns for possible formats
    const columns = analyzeColumns(rows, headers);
    return {
        headers,
        rows,
        columns,
        hasHeaders
    };
}
/**
 * Parse tab-delimited data
 */
function parseTabData(lines) {
    // Use a more careful approach for tab-delimited data
    const rawRows = lines.map(line => {
        // Preserve empty cells when splitting by tabs
        const cells = line.split('\t');
        return cells;
    });
    // Determine if the first row is headers
    const hasHeaders = detectHeaders(rawRows);
    const headers = hasHeaders ? rawRows[0] : rawRows[0].map((_, index) => `Column ${index + 1}`);
    const rows = hasHeaders ? rawRows.slice(1) : rawRows;
    // Analyze columns for possible formats
    const columns = analyzeColumns(rows, headers);
    return {
        headers,
        rows,
        columns,
        hasHeaders
    };
}
/**
 * Detect if the first row is likely to be headers
 */
function detectHeaders(rows) {
    if (rows.length < 2)
        return false;
    const firstRow = rows[0];
    const secondRow = rows[1];
    // If any cell in the first row is empty but the corresponding cell in the second row is not,
    // it's likely not a header
    for (let i = 0; i < firstRow.length; i++) {
        if (!firstRow[i].trim() && secondRow[i] && secondRow[i].trim()) {
            return false;
        }
    }
    // Check if the first row has a different data type pattern than the rest
    let headerDifference = 0;
    for (let i = 0; i < firstRow.length; i++) {
        const headerCell = firstRow[i].trim();
        // Skip empty cells
        if (!headerCell)
            continue;
        // Check if header is numeric while data is not, or vice versa
        const headerIsNumeric = !isNaN(Number(headerCell.replace(/[,\. ]/g, '')));
        let dataIsNumeric = true;
        for (let j = 1; j < Math.min(rows.length, 5); j++) {
            if (i >= rows[j].length)
                continue;
            const dataCell = rows[j][i].trim();
            if (!dataCell)
                continue;
            if (isNaN(Number(dataCell.replace(/[,\. ]/g, '')))) {
                dataIsNumeric = false;
                break;
            }
        }
        if (headerIsNumeric !== dataIsNumeric) {
            headerDifference++;
        }
    }
    // If more than 50% of columns show a different pattern between header and data,
    // it's likely that the first row is a header
    return headerDifference > firstRow.length / 2;
}
/**
 * Analyze columns for possible formats
 */
function analyzeColumns(rows, headers) {
    return headers.map((header, colIndex) => {
        // Get all values for this column
        const values = rows.map(row => colIndex < row.length ? row[colIndex] : '').filter(val => val.trim() !== '');
        if (values.length === 0) {
            return {
                index: colIndex,
                possibleFormats: [],
                selectedFormat: null,
                targetFormat: null,
                mightContainYears: false
            };
        }
        // Check for date formats
        const dateFormats = detectDateFormats(values);
        // Check for number formats
        const numberFormats = detectNumberFormats(values);
        // Check if there might be 4-digit numbers that could be years
        // We'll use this to inform UI choices for the user
        const mightContainYears = checkForPotentialYears(values);
        // Combine and sort by confidence
        const possibleFormats = [...dateFormats, ...numberFormats]
            .sort((a, b) => b.confidence - a.confidence);
        return {
            index: colIndex,
            possibleFormats,
            selectedFormat: possibleFormats.length > 0 ? possibleFormats[0].formatKey : null,
            targetFormat: null,
            mightContainYears
        };
    });
}
/**
 * Check if a column might contain 4-digit integers that could be interpreted as years
 * Used to inform UI choices for the user
 */
function checkForPotentialYears(values) {
    let fourDigitIntegers = 0;
    let yearLikeIntegers = 0;
    // Check each value
    for (const value of values) {
        const trimmedValue = value.trim();
        // If it's a 4-digit integer
        if (/^\d{4}$/.test(trimmedValue)) {
            fourDigitIntegers++;
            // If it's in the typical year range
            const num = parseInt(trimmedValue, 10);
            if (num >= 1900 && num <= 2100) {
                yearLikeIntegers++;
            }
        }
    }
    // If we have at least some 4-digit integers and more than half of them look like years
    return fourDigitIntegers > 0 && yearLikeIntegers / fourDigitIntegers > 0.5;
}
/**
 * Detect possible date formats in a column
 */
function detectDateFormats(values) {
    const results = [];
    for (const format of DATE_FORMATS) {
        let matchCount = 0;
        for (const value of values) {
            if (format.regex.test(value.trim())) {
                matchCount++;
            }
        }
        const confidence = values.length > 0 ? matchCount / values.length : 0;
        // Only include formats with at least some matches
        if (matchCount > 0) {
            results.push({
                isDetected: true,
                confidence,
                formatKey: format.key,
                formatName: format.name
            });
        }
    }
    // Check for potential unix timestamp or 4-digit integer that could be a year
    // but only if no other date formats were detected and not intended to be flagged as integer
    if (results.length === 0) {
        let fourDigitCount = 0;
        let yearLikeCount = 0;
        let unixTimestampCount = 0;
        for (const value of values) {
            const trimmedValue = value.trim();
            // Check if it's a pure number
            if (/^\d+$/.test(trimmedValue)) {
                const num = parseInt(trimmedValue, 10);
                // Count 4-digit numbers
                if (trimmedValue.length === 4) {
                    fourDigitCount++;
                    // Only count as year-like if it's in a typical year range
                    if (num >= 1900 && num <= 2100) {
                        yearLikeCount++;
                    }
                }
                else if (num > 946684800 && num < 2524608000) { // Unix timestamps from 2000 to 2050
                    unixTimestampCount++;
                }
            }
        }
        // Calculate confidence values
        const fourDigitConfidence = values.length > 0 ? fourDigitCount / values.length : 0;
        const yearConfidence = values.length > 0 ? yearLikeCount / values.length : 0;
        const unixConfidence = values.length > 0 ? unixTimestampCount / values.length : 0;
        // Only add year format as a secondary option with reduced confidence
        // This ensures integer detection takes priority
        if (yearLikeCount > 0) {
            results.push({
                isDetected: true,
                // Reduce confidence for year-like values to prioritize integer format
                confidence: yearConfidence * 0.6, // 60% of original confidence to rank lower than integers
                formatKey: 'YYYY',
                formatName: 'Year Only (YYYY)'
            });
        }
        if (unixTimestampCount > 0) {
            results.push({
                isDetected: true,
                confidence: unixConfidence,
                formatKey: 'unix_timestamp',
                formatName: 'Timestamp'
            });
        }
    }
    return results;
}
/**
 * Detect possible number formats in a column
 */
function detectNumberFormats(values) {
    const results = [];
    // Track 4-digit integers specifically
    let fourDigitIntegerCount = 0;
    const totalCount = values.length;
    for (const format of NUMBER_FORMATS) {
        let matchCount = 0;
        for (const value of values) {
            const trimmedValue = value.trim();
            if (format.regex.test(trimmedValue)) {
                matchCount++;
                // Count 4-digit integers specifically when processing the integer format
                if (format.key === 'integer' && trimmedValue.length === 4 && /^\d{4}$/.test(trimmedValue)) {
                    fourDigitIntegerCount++;
                }
            }
        }
        const confidence = values.length > 0 ? matchCount / values.length : 0;
        // Only include formats with at least some matches
        if (matchCount > 0) {
            // For integer format with 4-digit numbers, boost confidence slightly to prioritize over year detection
            const adjustedConfidence = (format.key === 'integer' && fourDigitIntegerCount > 0 && fourDigitIntegerCount === matchCount)
                ? confidence * 1.1 // Boost confidence for 4-digit integers
                : confidence;
            results.push({
                isDetected: true,
                confidence: adjustedConfidence,
                formatKey: format.key,
                formatName: format.name
            });
        }
    }
    return results;
}
/**
 * Convert a date string from one format to another
 */
function convertDate(dateStr, fromFormat, toFormat) {
    // Parse the date based on the fromFormat
    const date = parseDate(dateStr, fromFormat);
    if (!date || isNaN(date.getTime())) {
        return dateStr; // Return original if parsing fails
    }
    // Format the date based on the toFormat
    return formatDate(date, toFormat);
}
/**
 * Parse a date string based on a format
 */
function parseDate(dateStr, format) {
    const cleanDateStr = dateStr.trim();
    let day, month, year;
    // Handle different date formats
    if (format === 'MM/DD/YYYY' || format === 'MM-DD-YYYY') {
        const separator = format.includes('/') ? '/' : '-';
        const parts = cleanDateStr.split(separator);
        if (parts.length !== 3)
            return null;
        month = parseInt(parts[0], 10) - 1; // JS months are 0-based
        day = parseInt(parts[1], 10);
        year = parseInt(parts[2], 10);
        if (year < 100)
            year += year < 50 ? 2000 : 1900; // Handle 2-digit years
    }
    else if (format === 'DD/MM/YYYY' || format === 'DD-MM-YYYY' || format === 'DD.MM.YYYY') {
        const separator = format.includes('/') ? '/' : format.includes('-') ? '-' : '.';
        const parts = cleanDateStr.split(separator);
        if (parts.length !== 3)
            return null;
        day = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10) - 1;
        year = parseInt(parts[2], 10);
        if (year < 100)
            year += year < 50 ? 2000 : 1900;
    }
    else if (format === 'YYYY/MM/DD' || format === 'YYYY-MM-DD' || format === 'YYYY.MM.DD') {
        const separator = format.includes('/') ? '/' : format.includes('-') ? '-' : '.';
        const parts = cleanDateStr.split(separator);
        if (parts.length !== 3)
            return null;
        year = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10) - 1;
        day = parseInt(parts[2], 10);
    }
    else if (format === 'MMMM DD, YYYY') {
        const match = cleanDateStr.match(/([A-Za-z]+)\s+(0?[1-9]|[12][0-9]|3[01]),\s+(\d{4})/);
        if (!match)
            return null;
        const monthName = match[1];
        day = parseInt(match[2], 10);
        year = parseInt(match[3], 10);
        // Convert month name to number
        month = MONTH_NAMES.findIndex(m => m.toLowerCase().startsWith(monthName.toLowerCase()));
        if (month === -1)
            return null;
    }
    else if (format === 'DD MMMM YYYY') {
        const match = cleanDateStr.match(/(0?[1-9]|[12][0-9]|3[01])\s+([A-Za-z]+)\s+(\d{4})/);
        if (!match)
            return null;
        day = parseInt(match[1], 10);
        const monthName = match[2];
        year = parseInt(match[3], 10);
        // Convert month name to number
        month = MONTH_NAMES.findIndex(m => m.toLowerCase().startsWith(monthName.toLowerCase()));
        if (month === -1)
            return null;
    }
    else if (format === 'MMM DD' || format === 'MMM DD YYYY') {
        const match = cleanDateStr.match(/([A-Za-z]{3})\s+(0?[1-9]|[12][0-9]|3[01])(?:\s+(\d{4}))?/);
        if (!match)
            return null;
        const monthAbbr = match[1].toUpperCase();
        day = parseInt(match[2], 10);
        year = match[3] ? parseInt(match[3], 10) : new Date().getFullYear(); // Default to current year if not provided
        // Convert month abbreviation to number
        month = MONTH_ABBR_MAP[monthAbbr];
        if (month === undefined)
            return null;
    }
    else if (format === 'DD MMM' || format === 'DD MMM YYYY') {
        const match = cleanDateStr.match(/(0?[1-9]|[12][0-9]|3[01])\s+([A-Za-z]{3})(?:\s+(\d{4}))?/);
        if (!match)
            return null;
        day = parseInt(match[1], 10);
        const monthAbbr = match[2].toUpperCase();
        year = match[3] ? parseInt(match[3], 10) : new Date().getFullYear(); // Default to current year if not provided
        // Convert month abbreviation to number
        month = MONTH_ABBR_MAP[monthAbbr];
        if (month === undefined)
            return null;
    }
    else if (format === 'YYYY MMM') {
        const match = cleanDateStr.match(/(\d{4})\s+([A-Za-z]{3})/);
        if (!match)
            return null;
        year = parseInt(match[1], 10);
        const monthAbbr = match[2].toUpperCase();
        // Convert month abbreviation to number
        month = MONTH_ABBR_MAP[monthAbbr];
        if (month === undefined)
            return null;
        // Default to 1st day of the month
        day = 1;
    }
    else if (format === 'YYYY') {
        const match = cleanDateStr.match(/(\d{4})/);
        if (!match)
            return null;
        year = parseInt(match[1], 10);
        // For year-only formats, default to January 1st
        month = 0;
        day = 1;
    }
    else if (format === 'unix_timestamp') {
        const timestamp = parseInt(cleanDateStr, 10);
        // Check if it's milliseconds or seconds format
        const date = timestamp > 9999999999
            ? new Date(timestamp) // milliseconds
            : new Date(timestamp * 1000); // seconds
        if (isNaN(date.getTime()))
            return null;
        return date;
    }
    else {
        return null;
    }
    // Validate date components
    if (isNaN(day) || isNaN(month) || isNaN(year) ||
        month < 0 || month > 11 || day < 1 || day > 31) {
        return null;
    }
    return new Date(year, month, day);
}
/**
 * Format a date based on a format string
 */
function formatDate(date, format) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    // Pad with leading zeros
    const dayStr = day < 10 ? `0${day}` : `${day}`;
    const monthStr = month < 10 ? `0${month}` : `${month}`;
    const yearStr = `${year}`;
    // Format the date based on the format string
    if (format === 'MM/DD/YYYY') {
        return `${monthStr}/${dayStr}/${yearStr}`;
    }
    else if (format === 'DD/MM/YYYY') {
        return `${dayStr}/${monthStr}/${yearStr}`;
    }
    else if (format === 'YYYY/MM/DD') {
        return `${yearStr}/${monthStr}/${dayStr}`;
    }
    else if (format === 'MM-DD-YYYY') {
        return `${monthStr}-${dayStr}-${yearStr}`;
    }
    else if (format === 'DD-MM-YYYY') {
        return `${dayStr}-${monthStr}-${yearStr}`;
    }
    else if (format === 'YYYY-MM-DD') {
        return `${yearStr}-${monthStr}-${dayStr}`;
    }
    else if (format === 'DD.MM.YYYY') {
        return `${dayStr}.${monthStr}.${yearStr}`;
    }
    else if (format === 'YYYY.MM.DD') {
        return `${yearStr}.${monthStr}.${dayStr}`;
    }
    else if (format === 'MMMM DD, YYYY') {
        return `${MONTH_NAMES[month - 1]} ${dayStr}, ${yearStr}`;
    }
    else if (format === 'DD MMMM YYYY') {
        return `${dayStr} ${MONTH_NAMES[month - 1]} ${yearStr}`;
    }
    else if (format === 'MMM DD') {
        return `${MONTH_ABBRS[month - 1]} ${dayStr}`;
    }
    else if (format === 'MMM DD YYYY') {
        return `${MONTH_ABBRS[month - 1]} ${dayStr} ${yearStr}`;
    }
    else if (format === 'DD MMM') {
        return `${dayStr} ${MONTH_ABBRS[month - 1]}`;
    }
    else if (format === 'DD MMM YYYY') {
        return `${dayStr} ${MONTH_ABBRS[month - 1]} ${yearStr}`;
    }
    else if (format === 'YYYY MMM') {
        return `${yearStr} ${MONTH_ABBRS[month - 1]}`;
    }
    else if (format === 'YYYY') {
        return yearStr;
    }
    else if (format === 'unix_timestamp') {
        return `${Math.floor(date.getTime() / 1000)}`;
    }
    else {
        return date.toISOString();
    }
}
/**
 * Convert a number string from one format to another
 */
function convertNumber(numStr, fromFormat, toFormat) {
    // Parse the number based on the fromFormat
    const num = parseNumber(numStr, fromFormat);
    if (num === null) {
        return numStr; // Return original if parsing fails
    }
    // Format the number based on the toFormat
    return formatNumber(num, toFormat);
}
/**
 * Parse a number string based on a format
 */
function parseNumber(numStr, format) {
    const cleanNumStr = numStr.trim();
    // Handle different number formats
    if (format === 'comma_decimal_point') {
        // 1,234.56 format
        const parsed = Number(cleanNumStr.replace(/,/g, ''));
        return isNaN(parsed) ? null : parsed;
    }
    else if (format === 'point_decimal_comma') {
        // 1.234,56 format
        const parsed = Number(cleanNumStr.replace(/\./g, '').replace(',', '.'));
        return isNaN(parsed) ? null : parsed;
    }
    else if (format === 'space_decimal_point') {
        // 1 234.56 format
        const parsed = Number(cleanNumStr.replace(/\s/g, ''));
        return isNaN(parsed) ? null : parsed;
    }
    else if (format === 'space_decimal_comma') {
        // 1 234,56 format
        const parsed = Number(cleanNumStr.replace(/\s/g, '').replace(',', '.'));
        return isNaN(parsed) ? null : parsed;
    }
    else if (format === 'no_separator_decimal_point') {
        // 1234.56 format
        return Number(cleanNumStr);
    }
    else if (format === 'no_separator_decimal_comma') {
        // 1234,56 format
        const parsed = Number(cleanNumStr.replace(',', '.'));
        return isNaN(parsed) ? null : parsed;
    }
    else if (format === 'integer') {
        // 1234 format
        return Number(cleanNumStr);
    }
    return null;
}
/**
 * Format a number based on a format string
 */
function formatNumber(num, format) {
    // Handle different output formats
    if (format === 'comma_decimal_point') {
        // 1,234.56 format
        return num.toLocaleString('en-US', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        });
    }
    else if (format === 'point_decimal_comma') {
        // 1.234,56 format
        return num.toLocaleString('de-DE', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        });
    }
    else if (format === 'space_decimal_point') {
        // 1 234.56 format
        return num.toLocaleString('en-US', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        }).replace(/,/g, ' ');
    }
    else if (format === 'space_decimal_comma') {
        // 1 234,56 format
        return num.toLocaleString('de-DE', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        }).replace(/\./g, ' ');
    }
    else if (format === 'no_separator_decimal_point') {
        // 1234.56 format
        return num.toFixed(getDecimalPlaces(num));
    }
    else if (format === 'no_separator_decimal_comma') {
        // 1234,56 format
        return num.toFixed(getDecimalPlaces(num)).replace('.', ',');
    }
    else if (format === 'integer') {
        // 1234 format
        return Math.round(num).toString();
    }
    // Default to standard format
    return num.toString();
}
/**
 * Get the number of decimal places in a number
 */
function getDecimalPlaces(num) {
    const match = num.toString().match(/(?:\.(\d+))?$/);
    return match && match[1] ? match[1].length : 0;
}


/***/ }),

/***/ "./src/utils/storage.ts":
/*!******************************!*\
  !*** ./src/utils/storage.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_PREFERENCES: () => (/* binding */ DEFAULT_PREFERENCES),
/* harmony export */   loadPreferences: () => (/* binding */ loadPreferences),
/* harmony export */   savePreferences: () => (/* binding */ savePreferences)
/* harmony export */ });
/**
 * Storage utilities for Chrome extension
 */
// Default user preferences
const DEFAULT_PREFERENCES = {
    dateFormat: 'YYYY-MM-DD', // ISO format as default
    numberFormat: 'comma_decimal_point', // Standard English format
    forceFormat: false, // Don't force format conversion by default
    outputFormat: 'auto', // Auto-detect output format by default
    originalFormat: true, // Keep original format by default
};
/**
 * Save user preferences to Chrome storage
 */
function savePreferences(preferences) {
    return new Promise((resolve, reject) => {
        chrome.storage.sync.set({ preferences }, () => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            else {
                resolve();
            }
        });
    });
}
/**
 * Load user preferences from Chrome storage
 */
function loadPreferences() {
    return new Promise((resolve, reject) => {
        chrome.storage.sync.get('preferences', (result) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            else {
                resolve(result.preferences || DEFAULT_PREFERENCES);
            }
        });
    });
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./src/popup.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/formatDetector */ "./src/utils/formatDetector.ts");
/* harmony import */ var _utils_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/storage */ "./src/utils/storage.ts");
/* harmony import */ var _utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/extPayHandler */ "./src/utils/extPayHandler.ts");
/// <reference types="chrome" />



// Month names and abbreviations for formatting examples
const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
const MONTH_ABBRS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
// Global state
let parsedData = null;
let userPreferences = _utils_storage__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_PREFERENCES;
let forceFormat = false;
let clipboardMonitorInterval = null;
let lastClipboardText = null;
let isSubscribed = false; // Track subscription status globally
let isDevelopmentMode = false; // Track development mode for testing
let devModeSubscriptionOverride = null; // Store the dev mode subscription override
let originalFormatType = null; // Track original data format
// DOM elements
const formatDetectionSection = document.getElementById('formatDetectionSection');
const noDataSection = document.getElementById('noDataSection');
const dataPreviewContainer = document.getElementById('dataPreview');
const dateFormatSelect = document.getElementById('dateFormatSelect');
const numberFormatSelect = document.getElementById('numberFormatSelect');
let outputFormatSelect = document.getElementById('outputFormatSelect');
let outputFormatDesktop = document.getElementById('outputFormatDesktop');
const forceFormatCheckbox = document.getElementById('forceFormatCheckbox');
let copyBtn = document.getElementById('copyBtn');
const resetBtn = document.getElementById('resetBtn');
const applyBtn = document.getElementById('applyBtn');
const subscriptionBtn = document.getElementById('subscriptionBtn');
const subscriptionText = document.getElementById('subscriptionText');
let exportBtn = document.getElementById('exportBtn');
let devModeIndicator; // Development mode indicator
// Initialize the extension
document.addEventListener('DOMContentLoaded', async () => {
    await initializeExtension();
    // Set up event listeners
    if (copyBtn) {
        copyBtn.addEventListener('click', handleCopyButtonClick);
    }
    resetBtn.addEventListener('click', handleResetButtonClick);
    dateFormatSelect.addEventListener('change', handleDateFormatChange);
    numberFormatSelect.addEventListener('change', handleNumberFormatChange);
    outputFormatSelect.addEventListener('change', handleOutputFormatChange);
    outputFormatDesktop.addEventListener('change', handleOutputFormatDesktopChange);
    forceFormatCheckbox.addEventListener('change', handleForceFormatChange);
    subscriptionBtn.addEventListener('click', handleSubscriptionButtonClick);
    // Add listener for the new apply button
    if (applyBtn) {
        applyBtn.addEventListener('click', handleApplyButtonClick);
    }
    else {
        // Create apply button if it doesn't exist in HTML
        createApplyButton();
    }
    // Add listener for export button if it exists in HTML
    if (exportBtn) {
        exportBtn.addEventListener('click', handleExportButtonClick);
    }
    // Create file import option
    createFileImportOption();
    // Add drag and drop support
    setupDragAndDrop();
    // Create the action buttons container if it doesn't exist
    const actionContainer = document.querySelector('.popup-actions') || createActionContainer();
    // Create and add the copy button if it doesn't exist
    if (!copyBtn) {
        createCopyButton(actionContainer);
    }
    // Create and add the export button if it doesn't exist
    if (!exportBtn) {
        createExportButton(actionContainer);
    }
    // Create and add the output format dropdown if it doesn't exist
    if (!document.querySelector('.output-format-container')) {
        createOutputFormatDropdown(actionContainer);
    }
    // Add CSS styles for Pro features and export modal
    addProFeatureStyles();
    // Check if running in development mode
    await checkDevelopmentMode();
    // Create development mode indicator
    createDevModeIndicator();
    // Set document title to match extension name
    document.title = 'CommaDashDotXL';
    // Initially hide the loading indicator
    document.querySelector('.loading-indicator')?.classList.remove('active');
    // Set up focus/blur event handlers for clipboard monitoring
    window.addEventListener('focus', startClipboardMonitoring);
    window.addEventListener('blur', stopClipboardMonitoring);
    // Wait for focus before trying to read clipboard
    if (document.hasFocus()) {
        await autoDetectFormats();
        startClipboardMonitoring();
    }
    else {
        // Show loading indicator
        noDataSection.classList.remove('hidden');
        document.querySelector('.loading-indicator')?.classList.add('active');
        // Wait for focus before trying to access clipboard
        window.addEventListener('focus', async () => {
            await autoDetectFormats();
        }, { once: true });
    }
    // Update subscription button and Pro features
    await updateSubscriptionStatus();
    // Try to restore dev mode subscription override
    restoreDevModeStatus();
});
/**
 * Create the action container if it doesn't exist
 */
function createActionContainer() {
    const container = document.createElement('div');
    container.className = 'popup-actions';
    document.body.appendChild(container);
    return container;
}
/**
 * Create the copy button if it doesn't exist
 */
function createCopyButton(container) {
    const button = document.createElement('button');
    button.id = 'copyBtn';
    button.className = 'action-button';
    button.textContent = 'Copy';
    button.title = 'Copy formatted data to clipboard';
    button.addEventListener('click', handleCopyButtonClick);
    container.appendChild(button);
    copyBtn = button;
    return button;
}
/**
 * Check if the extension is running in development mode (unpacked)
 */
async function checkDevelopmentMode() {
    return new Promise((resolve) => {
        chrome.management.getSelf((info) => {
            isDevelopmentMode = info.installType === 'development';
            // If in dev mode, update the UI
            if (isDevelopmentMode) {
                devModeIndicator?.classList.remove('hidden');
                console.log('Running in development mode - subscription features available for testing');
            }
            resolve();
        });
    });
}
/**
 * Restore development mode subscription override from storage
 */
async function restoreDevModeStatus() {
    if (!isDevelopmentMode)
        return;
    // Try to get stored dev mode settings
    try {
        const result = await new Promise((resolve) => {
            chrome.storage.local.get(['devModeSubscriptionOverride'], (result) => {
                resolve(result);
            });
        });
        if (result && result.devModeSubscriptionOverride !== undefined) {
            devModeSubscriptionOverride = result.devModeSubscriptionOverride;
            isSubscribed = devModeSubscriptionOverride;
            // Update UI
            updateProFeatureState(exportBtn, isSubscribed);
            updateOutputFormatOptions();
            // Update subscription button text
            if (isSubscribed) {
                subscriptionText.textContent = 'Manage Subscription';
                subscriptionBtn.classList.add('subscribed');
            }
            else {
                subscriptionText.textContent = 'Subscribe';
                subscriptionBtn.classList.remove('subscribed');
            }
            console.log(`Restored dev mode subscription override: ${isSubscribed ? 'PRO' : 'FREE'} user`);
        }
    }
    catch (error) {
        console.error('Failed to restore dev mode settings', error);
    }
}
/**
 * Save development mode subscription override to storage
 */
async function saveDevModeStatus(isSubscribed) {
    if (!isDevelopmentMode)
        return;
    try {
        await new Promise((resolve) => {
            chrome.storage.local.set({ devModeSubscriptionOverride: isSubscribed }, () => {
                resolve();
            });
        });
        devModeSubscriptionOverride = isSubscribed;
        console.log(`Saved dev mode subscription override: ${isSubscribed ? 'PRO' : 'FREE'} user`);
    }
    catch (error) {
        console.error('Failed to save dev mode settings', error);
    }
}
/**
 * Create a development mode indicator
 */
function createDevModeIndicator() {
    devModeIndicator = document.createElement('div');
    devModeIndicator.className = 'dev-mode-indicator';
    devModeIndicator.textContent = 'DEV MODE';
    // Add toggle button to simulate subscription status
    const toggleSubscriptionBtn = document.createElement('button');
    toggleSubscriptionBtn.className = 'dev-toggle-subscription';
    toggleSubscriptionBtn.textContent = isSubscribed ? 'Simulate Free User' : 'Simulate Pro User';
    toggleSubscriptionBtn.addEventListener('click', async () => {
        // Only works in development mode
        if (isDevelopmentMode) {
            isSubscribed = !isSubscribed;
            // Save the override to persist across popup reloads
            await saveDevModeStatus(isSubscribed);
            // Update UI
            updateProFeatureState(exportBtn, isSubscribed);
            updateProFeatureState(outputFormatSelect, isSubscribed);
            if (outputFormatDesktop) {
                updateProFeatureState(outputFormatDesktop, isSubscribed);
            }
            updateOutputFormatOptions();
            toggleSubscriptionBtn.textContent = isSubscribed ? 'Simulate Free User' : 'Simulate Pro User';
            // Update subscription button text
            if (isSubscribed) {
                subscriptionText.textContent = 'Manage Subscription';
                subscriptionBtn.classList.add('subscribed');
            }
            else {
                subscriptionText.textContent = 'Subscribe';
                subscriptionBtn.classList.remove('subscribed');
            }
            showSuccess(`Subscription status toggled to: ${isSubscribed ? 'PRO' : 'FREE'}`);
        }
    });
    devModeIndicator.appendChild(toggleSubscriptionBtn);
    document.body.appendChild(devModeIndicator);
    // Make dev indicator initially visible in dev mode
    if (isDevelopmentMode) {
        devModeIndicator.classList.remove('hidden');
    }
}
/**
 * Create and append the export button
 */
function createExportButton(container) {
    exportBtn = document.createElement('button');
    exportBtn.id = 'exportBtn';
    exportBtn.className = 'action-button pro-feature';
    exportBtn.textContent = 'Export';
    exportBtn.title = 'Export data as CSV, XLS, etc. (Pro Feature)';
    // Add event listener
    exportBtn.addEventListener('click', handleExportButtonClick);
    // Add to container
    container.appendChild(exportBtn);
    // Initially disable the button (will be enabled if user is subscribed)
    updateProFeatureState(exportBtn, isSubscribed);
}
/**
 * Create the output format dropdown
 */
function createOutputFormatDropdown(container) {
    // Only create if not already in HTML
    if (outputFormatSelect && outputFormatDesktop) {
        // Just update the options
        updateOutputFormatOptions();
        return;
    }
    // If we're here we need to create the dynamic dropdown
    // Create label
    const label = document.createElement('label');
    label.textContent = 'Format:';
    label.className = 'output-format-label';
    // Create select element if not already defined
    if (!outputFormatSelect) {
        outputFormatSelect = document.createElement('select');
        outputFormatSelect.id = 'outputFormatSelect';
        outputFormatSelect.className = 'output-format-select';
        // Add event listener
        outputFormatSelect.addEventListener('change', handleOutputFormatChange);
    }
    // Create dropdown container
    const dropdownContainer = document.createElement('div');
    dropdownContainer.className = 'output-format-container';
    dropdownContainer.appendChild(label);
    dropdownContainer.appendChild(outputFormatSelect);
    // Add to container
    container.appendChild(dropdownContainer);
    // Populate options
    updateOutputFormatOptions();
}
/**
 * Update output format options based on subscription status
 */
function updateOutputFormatOptions() {
    const updateSelect = (select) => {
        if (!select)
            return;
        // Clear existing options first
        while (select.options.length) {
            select.remove(0);
        }
        // Add the options
        const formats = [
            { value: 'auto', text: 'Auto (Original Format)', proOnly: false },
            { value: 'comma', text: 'CSV (Comma-separated)', proOnly: true },
            { value: 'tab', text: 'TSV (Tab-separated)', proOnly: true },
            { value: 'semicolon', text: 'SSV (Semicolon-separated)', proOnly: true },
            { value: 'pipe', text: 'Pipe-separated', proOnly: true },
            { value: 'json', text: 'JSON', proOnly: true }
        ];
        formats.forEach(format => {
            const option = document.createElement('option');
            option.value = format.value;
            option.textContent = format.text;
            // Mark Pro-only options
            if (format.proOnly && !isSubscribed) {
                option.className = 'pro-option';
                option.textContent = format.text + ' (PRO)';
            }
            select.add(option);
        });
        // Set the current value
        select.value = userPreferences.outputFormat;
        // If not subscribed and not using auto, reset to auto
        if (!isSubscribed && userPreferences.outputFormat !== 'auto') {
            select.value = 'auto';
        }
        // Update the visual state
        updateProFeatureState(select, isSubscribed);
    };
    // Update both selects
    updateSelect(outputFormatSelect);
    updateSelect(outputFormatDesktop);
}
/**
 * Handle export button click
 */
function handleExportButtonClick() {
    if (!isSubscribed) {
        (0,_utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__.openPaymentPage)();
        return;
    }
    if (!parsedData) {
        showError('No data to export.');
        return;
    }
    // Get the converted data
    const convertedData = convertParsedData();
    // Use the currently selected output format
    const currentFormat = userPreferences.outputFormat;
    // Export based on the selected format
    switch (currentFormat) {
        case 'comma':
            exportAsCSV(convertedData);
            break;
        case 'tab':
            exportAsTSV(convertedData);
            break;
        case 'json':
            exportAsJSON(convertedData);
            break;
        case 'semicolon':
            // Export as semicolon-separated values
            const ssvContent = formatDataForOutput(convertedData, ';');
            downloadFile(ssvContent, 'data.csv', 'text/csv');
            break;
        case 'pipe':
            // Export as pipe-separated values
            const psvContent = formatDataForOutput(convertedData, '|');
            downloadFile(psvContent, 'data.txt', 'text/plain');
            break;
        case 'auto':
        default:
            // Use the stored original format type if available
            if (originalFormatType) {
                switch (originalFormatType) {
                    case 'json':
                        exportAsJSON(convertedData);
                        return;
                    case 'spreadsheet':
                    case 'tsv':
                        exportAsTSV(convertedData);
                        return;
                    case 'csv':
                        exportAsCSV(convertedData);
                        return;
                    case 'ssv':
                        // Export as semicolon-separated values
                        const ssvContent = formatDataForOutput(convertedData, ';');
                        downloadFile(ssvContent, 'data.csv', 'text/csv');
                        return;
                    case 'psv':
                        // Export as pipe-separated values
                        const psvContent = formatDataForOutput(convertedData, '|');
                        downloadFile(psvContent, 'data.txt', 'text/plain');
                        return;
                }
            }
            // Fallback to delimiter detection if originalFormatType is not available
            const originalDelimiter = detectOriginalDelimiter(lastClipboardText || '');
            if (originalDelimiter) {
                const content = formatDataForOutput(convertedData, originalDelimiter);
                // Determine file extension based on delimiter
                let extension = 'txt';
                let mimeType = 'text/plain';
                if (originalDelimiter === ',') {
                    extension = 'csv';
                    mimeType = 'text/csv';
                }
                else if (originalDelimiter === '\t') {
                    extension = 'tsv';
                    mimeType = 'text/tab-separated-values';
                }
                else if (originalDelimiter === ';') {
                    extension = 'csv';
                    mimeType = 'text/csv';
                }
                downloadFile(content, `data.${extension}`, mimeType);
            }
            else {
                // Default to CSV if original delimiter can't be detected
                exportAsCSV(convertedData);
            }
            break;
    }
}
/**
 * Export data as CSV
 */
function exportAsCSV(data) {
    const csvContent = formatDataForOutput(data, ',');
    downloadFile(csvContent, 'data.csv', 'text/csv');
}
/**
 * Export data as TSV
 */
function exportAsTSV(data) {
    const tsvContent = formatDataForOutput(data, '\t');
    downloadFile(tsvContent, 'data.tsv', 'text/tab-separated-values');
}
/**
 * Export data as XLS (CSV format for Excel)
 */
function exportAsXLS(data) {
    const csvContent = formatDataForOutput(data, ',');
    downloadFile(csvContent, 'data.csv', 'text/csv');
}
/**
 * Export data as JSON
 */
function exportAsJSON(data) {
    // Convert tabular data to JSON
    const jsonData = [];
    const headers = data.headers;
    data.rows.forEach(row => {
        const rowObj = {};
        row.forEach((cell, index) => {
            // Use header as key if available, otherwise use column index
            const key = data.hasHeaders ? headers[index] : `Column${index + 1}`;
            rowObj[key] = cell;
        });
        jsonData.push(rowObj);
    });
    const jsonContent = JSON.stringify(jsonData, null, 2);
    downloadFile(jsonContent, 'data.json', 'application/json');
}
/**
 * Format data for output with the specified delimiter
 */
function formatDataForOutput(data, delimiter) {
    // Create header row if original data had headers
    const rows = [];
    if (data.hasHeaders) {
        rows.push(data.headers.join(delimiter));
    }
    // Add data rows
    data.rows.forEach(row => {
        // Handle special characters and quoting if needed
        const formattedRow = row.map(cell => {
            // If cell contains delimiter, newline, or quotes, wrap in quotes
            if (cell.includes(delimiter) || cell.includes('\n') || cell.includes('"')) {
                return `"${cell.replace(/"/g, '""')}"`;
            }
            return cell;
        });
        rows.push(formattedRow.join(delimiter));
    });
    return rows.join('\n');
}
/**
 * Download file to user's device
 */
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
}
/**
 * Create and append the apply button if not present in HTML
 */
function createApplyButton() {
    const applyButtonContainer = document.querySelector('.popup-actions') || document.body;
    const button = document.createElement('button');
    button.id = 'applyBtn';
    button.className = 'action-button';
    button.textContent = 'Apply Format to All';
    button.title = 'Apply the selected date and number formats to all columns';
    // Add event listener
    button.addEventListener('click', handleApplyButtonClick);
    // Insert before the copy button if possible
    if (copyBtn && copyBtn.parentNode) {
        copyBtn.parentNode.insertBefore(button, copyBtn);
    }
    else {
        applyButtonContainer.appendChild(button);
    }
}
/**
 * Handle apply button click
 */
function handleApplyButtonClick() {
    if (!parsedData) {
        showError('No data to apply formats to.');
        return;
    }
    // Apply selected date and number formats to all columns
    parsedData.columns.forEach(column => {
        if (column.selectedFormat) {
            // Check if this is a date format
            if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === column.selectedFormat)) {
                column.targetFormat = userPreferences.dateFormat;
            }
            // Check if this is a number format
            else if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === column.selectedFormat)) {
                column.targetFormat = userPreferences.numberFormat;
            }
        }
    });
    // Update the preview
    updateDataPreview();
    showSuccess('Applied formats to all columns');
}
/**
 * Initialize the extension
 */
async function initializeExtension() {
    // Load user preferences
    try {
        userPreferences = await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.loadPreferences)();
    }
    catch (error) {
        console.error('Failed to load preferences:', error);
        userPreferences = _utils_storage__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_PREFERENCES;
    }
    // Populate format select dropdowns
    populateDateFormatSelect();
    populateNumberFormatSelect();
    // Set initial values from user preferences
    dateFormatSelect.value = userPreferences.dateFormat;
    numberFormatSelect.value = userPreferences.numberFormat;
    forceFormatCheckbox.checked = userPreferences.forceFormat || false;
    forceFormat = forceFormatCheckbox.checked;
    // Add event listeners
    dateFormatSelect?.addEventListener('change', handleDateFormatChange);
    numberFormatSelect?.addEventListener('change', handleNumberFormatChange);
    outputFormatSelect?.addEventListener('change', handleOutputFormatChange);
    outputFormatDesktop?.addEventListener('change', handleOutputFormatDesktopChange);
    forceFormatCheckbox?.addEventListener('change', handleForceFormatChange);
    copyBtn?.addEventListener('click', handleCopyButtonClick);
    resetBtn?.addEventListener('click', handleResetButtonClick);
    // Only add event listener if the button exists
    if (applyBtn) {
        applyBtn.addEventListener('click', handleApplyButtonClick);
    }
    subscriptionBtn?.addEventListener('click', handleSubscriptionButtonClick);
}
/**
 * Populate the date format select dropdown
 */
function populateDateFormatSelect() {
    dateFormatSelect.innerHTML = '';
    _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.forEach(format => {
        const option = document.createElement('option');
        option.value = format.key;
        option.textContent = format.name;
        dateFormatSelect.appendChild(option);
    });
}
/**
 * Populate the number format select dropdown
 */
function populateNumberFormatSelect() {
    numberFormatSelect.innerHTML = '';
    _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.forEach(format => {
        const option = document.createElement('option');
        option.value = format.key;
        option.textContent = format.name;
        numberFormatSelect.appendChild(option);
    });
}
/**
 * Auto-detect formats from clipboard and update UI
 */
async function autoDetectFormats() {
    try {
        showElement("loadingSpinner");
        // Read from clipboard and check if it's spreadsheet data
        const { text, isSpreadsheetData } = await readClipboard();
        // Process the clipboard data with the detected format information
        processClipboardData(text, isSpreadsheetData);
        // Update UI based on detection
        if (isSpreadsheetData) {
            console.log("Detected spreadsheet data (HTML format in clipboard)");
        }
        else {
            console.log("No HTML format detected, treating as plain text or JSON");
        }
    }
    catch (error) {
        console.error("Error reading clipboard:", error);
        console.error(`Full error details: ${JSON.stringify(error, Object.getOwnPropertyNames(error))}`);
        const errorMessage = error instanceof Error ? error.message : 'Failed to read clipboard data';
        showError(errorMessage);
    }
    finally {
        hideElement("loadingSpinner");
    }
}
/**
 * Attempt to read clipboard contents and determine if it's from a spreadsheet
 * This uses the Clipboard API to check for the presence of text/html format
 * which is typically present in data copied from spreadsheet applications
 */
async function readClipboard() {
    try {
        // Check if clipboard has items (modern API)
        if (navigator.clipboard && "read" in navigator.clipboard) {
            try {
                const items = await navigator.clipboard.read();
                for (const item of items) {
                    // If clipboard contains HTML format, it's likely from a spreadsheet
                    if (item.types.includes("text/html")) {
                        const text = await (await item.getType("text/plain")).text();
                        return { text, isSpreadsheetData: true };
                    }
                }
            }
            catch (clipboardReadError) {
                console.error("Failed to read clipboard with modern API:", clipboardReadError);
                console.error(`Full clipboard read error details: ${JSON.stringify(clipboardReadError, Object.getOwnPropertyNames(clipboardReadError))}`);
                // Fall through to standard text reading
            }
        }
        // Fallback to standard text reading
        const text = await navigator.clipboard.readText();
        return { text, isSpreadsheetData: false };
    }
    catch (error) {
        console.error("Failed to read clipboard:", error);
        console.error(`Full clipboard error details: ${JSON.stringify(error, Object.getOwnPropertyNames(error))}`);
        return { text: "", isSpreadsheetData: false };
    }
}
/**
 * Show element by ID
 */
function showElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.remove('hidden');
    }
}
/**
 * Hide element by ID
 */
function hideElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.add('hidden');
    }
}
/**
 * Update the data preview
 */
function updateDataPreview(data) {
    // If no data passed, use the global parsedData
    const dataToDisplay = data || parsedData;
    const previewElement = document.getElementById('dataPreview');
    if (!previewElement)
        return;
    if (!dataToDisplay || !dataToDisplay.rows || dataToDisplay.rows.length === 0) {
        previewElement.innerHTML = "<p>No data to preview</p>";
        return;
    }
    // Clear the container
    previewElement.innerHTML = '';
    // Create header table
    const headerTable = document.createElement('table');
    const thead = document.createElement('thead');
    // Create header row
    const headerRow = document.createElement('tr');
    dataToDisplay.headers.forEach(header => {
        const th = document.createElement('th');
        th.textContent = header;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    // Create input format buttons row
    const inputFormatRow = document.createElement('tr');
    inputFormatRow.className = 'format-buttons-row';
    dataToDisplay.columns.forEach((column, index) => {
        const th = document.createElement('th');
        // Create format buttons container
        const formatButtons = document.createElement('div');
        formatButtons.className = 'column-format-buttons';
        // Determine target format for this column
        let targetFormat = '';
        if (column.possibleFormats.length > 0) {
            const mostLikelyFormat = [...column.possibleFormats].sort((a, b) => b.confidence - a.confidence)[0];
            const isDateFormat = mostLikelyFormat && _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === mostLikelyFormat.formatKey);
            const isNumberFormat = mostLikelyFormat && _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === mostLikelyFormat.formatKey);
            if (isDateFormat) {
                targetFormat = column.targetFormat || userPreferences.dateFormat;
            }
            else if (isNumberFormat) {
                targetFormat = column.targetFormat || userPreferences.numberFormat;
            }
        }
        // Add input format buttons
        addInputFormatButtons(formatButtons, column, index, targetFormat);
        th.appendChild(formatButtons);
        inputFormatRow.appendChild(th);
    });
    thead.appendChild(inputFormatRow);
    headerTable.appendChild(thead);
    // Create scrollable data container
    const dataContainer = document.createElement('div');
    dataContainer.className = 'data-table-container';
    // Create data table
    const dataTable = document.createElement('table');
    const tbody = document.createElement('tbody');
    // Show up to 5 rows + 3 fading rows
    const maxVisibleRows = 5;
    const maxFadingRows = 3;
    const totalRows = Math.min(dataToDisplay.rows.length, maxVisibleRows + maxFadingRows);
    for (let i = 0; i < totalRows; i++) {
        const row = dataToDisplay.rows[i];
        const tr = document.createElement('tr');
        // Add fade-out effect for rows after maxVisibleRows
        if (i >= maxVisibleRows) {
            tr.className = 'fadeout-row';
            // Calculate opacity for fading rows
            const opacity = 1 - ((i - maxVisibleRows + 1) / (maxFadingRows + 1));
            tr.style.opacity = opacity.toString();
        }
        row.forEach((cell, colIndex) => {
            const td = document.createElement('td');
            // Get column info
            const column = dataToDisplay.columns[colIndex];
            // If the column has a selected format, show the converted value in the preview
            if (column && column.selectedFormat) {
                const originalFormat = column.selectedFormat;
                // Define the target format (may be custom per column)
                let targetFormat = '';
                // Determine target format
                if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === originalFormat)) {
                    targetFormat = column.targetFormat || userPreferences.dateFormat;
                    const convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertDate)(cell, originalFormat, targetFormat);
                    // Use converted value only if it's valid or force format is enabled
                    if (forceFormat || convertedValue !== cell) {
                        td.textContent = convertedValue;
                    }
                    else {
                        td.textContent = cell;
                        td.classList.add('format-error');
                        td.title = 'Could not convert to target format';
                    }
                }
                else if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === originalFormat)) {
                    targetFormat = column.targetFormat || userPreferences.numberFormat;
                    const convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertNumber)(cell, originalFormat, targetFormat);
                    // Use converted value only if it's valid or force format is enabled
                    if (forceFormat || convertedValue !== cell) {
                        td.textContent = convertedValue;
                    }
                    else {
                        td.textContent = cell;
                        td.classList.add('format-error');
                        td.title = 'Could not convert to target format';
                    }
                }
                else {
                    td.textContent = cell;
                }
            }
            else {
                td.textContent = cell;
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    }
    dataTable.appendChild(tbody);
    dataContainer.appendChild(dataTable);
    // Create footer table with output format buttons
    const footerTable = document.createElement('table');
    const tfoot = document.createElement('tfoot');
    const footerRow = document.createElement('tr');
    footerRow.className = 'format-footer-row';
    dataToDisplay.columns.forEach((column, index) => {
        const td = document.createElement('td');
        // Create format buttons container
        const formatButtons = document.createElement('div');
        formatButtons.className = 'column-format-buttons';
        // Add output format buttons if column has a selected format
        if (column && column.selectedFormat) {
            // Determine the type of the selected format
            const isDateFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === column.selectedFormat);
            const isNumberFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === column.selectedFormat);
            if (isDateFormat) {
                // Check if a custom target format is set for this column
                const targetFormat = column.targetFormat || userPreferences.dateFormat;
                // Get the selected format object
                const selectedFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.find(f => f.key === targetFormat);
                if (selectedFormat) {
                    // Add the selected format button
                    addFormatButton(formatButtons, selectedFormat, targetFormat, (formatKey) => {
                        // Update column-specific target format
                        if (parsedData && parsedData.columns[index]) {
                            parsedData.columns[index].targetFormat = formatKey;
                            updateDataPreview();
                        }
                    });
                }
                // Add "..." button with all other formats
                const otherFormats = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key !== targetFormat);
                if (otherFormats.length > 0) {
                    addMoreButton(formatButtons, _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS, [selectedFormat || _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS[0]], targetFormat, (formatKey) => {
                        // Update column-specific target format
                        if (parsedData && parsedData.columns[index]) {
                            parsedData.columns[index].targetFormat = formatKey;
                            updateDataPreview();
                        }
                    });
                }
            }
            else if (isNumberFormat) {
                // Check if a custom target format is set for this column
                const targetFormat = column.targetFormat || userPreferences.numberFormat;
                // Get the selected format object
                const selectedFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.find(f => f.key === targetFormat);
                if (selectedFormat) {
                    // Add the selected format button
                    addFormatButton(formatButtons, selectedFormat, targetFormat, (formatKey) => {
                        // Update column-specific target format
                        if (parsedData && parsedData.columns[index]) {
                            parsedData.columns[index].targetFormat = formatKey;
                            updateDataPreview();
                        }
                    });
                }
                // Add "..." button with all other formats
                const otherFormats = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.filter(f => f.key !== targetFormat);
                if (otherFormats.length > 0) {
                    addMoreButton(formatButtons, _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS, [selectedFormat || _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS[0]], targetFormat, (formatKey) => {
                        // Update column-specific target format
                        if (parsedData && parsedData.columns[index]) {
                            parsedData.columns[index].targetFormat = formatKey;
                            updateDataPreview();
                        }
                    });
                }
            }
        }
        td.appendChild(formatButtons);
        footerRow.appendChild(td);
    });
    tfoot.appendChild(footerRow);
    footerTable.appendChild(tfoot);
    // Add all components to the preview container
    previewElement.appendChild(headerTable);
    previewElement.appendChild(dataTable);
    previewElement.appendChild(footerTable);
    // Show row count info if there are more rows than shown
    if (dataToDisplay.rows.length > totalRows) {
        const rowCountInfo = document.createElement('div');
        rowCountInfo.className = 'row-count-info';
        rowCountInfo.textContent = `Showing ${totalRows} of ${dataToDisplay.rows.length} rows`;
        previewElement.appendChild(rowCountInfo);
    }
}
/**
 * Helper function to escape HTML special characters
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
/**
 * Process clipboard data
 */
function processClipboardData(text, isSpreadsheetData = false) {
    if (!text) {
        console.error("Error processing clipboard data: No text found in clipboard");
        showError("No text found in clipboard");
        return;
    }
    try {
        // Store the original clipboard text
        lastClipboardText = text;
        // Determine and store the original format type
        if (isSpreadsheetData) {
            originalFormatType = 'spreadsheet';
        }
        else if (text && text.trim().startsWith('{') && text.trim().endsWith('}') ||
            text && text.trim().startsWith('[') && text.trim().endsWith(']')) {
            originalFormatType = 'json';
        }
        else if (text.includes('\t')) {
            originalFormatType = 'tsv';
        }
        else if (text.includes(',')) {
            originalFormatType = 'csv';
        }
        else if (text.includes(';')) {
            originalFormatType = 'ssv';
        }
        else if (text.includes('|')) {
            originalFormatType = 'psv';
        }
        else {
            originalFormatType = null;
        }
        // Parse the data using the format detector
        // Pass the isSpreadsheetData flag to help the parser make better decisions
        const data = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.parseTabularData)(text, true, updateDataPreview, isSpreadsheetData);
        if (data) {
            // Store the parsed data globally
            parsedData = data;
            // Update the UI with the parsed data
            updateDataPreview(data);
            hideElement("errorMessage");
            showElement("dataControls");
            // Update UI
            formatDetectionSection.classList.remove('hidden');
            noDataSection.classList.add('hidden');
        }
    }
    catch (error) {
        console.error("Error processing clipboard data:", error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.error(`Full error details: ${JSON.stringify(error, Object.getOwnPropertyNames(error))}`);
        showError(`Error processing data: ${errorMessage}`);
    }
}
/**
 * Handle copy button click
 */
async function handleCopyButtonClick() {
    if (!parsedData) {
        showError('No data to copy.');
        return;
    }
    const convertedData = convertParsedData();
    const formattedText = formatDataForClipboard(convertedData);
    try {
        await navigator.clipboard.writeText(formattedText);
        showSuccess('Copied to clipboard!');
    }
    catch (error) {
        console.error('Failed to copy:', error);
        showError('Failed to copy to clipboard.');
    }
}
/**
 * Handle reset button click
 */
function handleResetButtonClick() {
    // Clear data and reset UI
    parsedData = null;
    lastClipboardText = null;
    originalFormatType = null;
    formatDetectionSection.classList.add('hidden');
    noDataSection.classList.remove('hidden');
    dataPreviewContainer.innerHTML = '';
    // Show the loading indicator
    document.querySelector('.loading-indicator')?.classList.add('active');
    // Start monitoring clipboard again
    if (document.hasFocus()) {
        startClipboardMonitoring();
    }
}
/**
 * Handle date format change
 */
async function handleDateFormatChange() {
    userPreferences.dateFormat = dateFormatSelect.value;
    await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
    updateDataPreview();
}
/**
 * Handle number format change
 */
async function handleNumberFormatChange() {
    userPreferences.numberFormat = numberFormatSelect.value;
    await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
    updateDataPreview();
}
/**
 * Handle output format change from the header dropdown
 */
async function handleOutputFormatChange() {
    const selectedOption = outputFormatSelect.options[outputFormatSelect.selectedIndex];
    // If not subscribed and option is a Pro feature, redirect to payment page
    if (!isSubscribed && selectedOption.value !== 'auto') {
        (0,_utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__.openPaymentPage)();
        // Reset to auto (original format)
        outputFormatSelect.value = 'auto';
        if (outputFormatDesktop) {
            outputFormatDesktop.value = 'auto';
        }
        // Also reset user preferences
        userPreferences.outputFormat = 'auto';
        userPreferences.originalFormat = true;
        await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
        return;
    }
    // Update preferences
    userPreferences.outputFormat = outputFormatSelect.value;
    userPreferences.originalFormat = outputFormatSelect.value === 'auto';
    await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
    // Sync with desktop dropdown
    if (outputFormatDesktop) {
        outputFormatDesktop.value = outputFormatSelect.value;
    }
}
/**
 * Handle output format change from the desktop dropdown
 */
async function handleOutputFormatDesktopChange() {
    const selectedOption = outputFormatDesktop.options[outputFormatDesktop.selectedIndex];
    // If not subscribed and option is a Pro feature, redirect to payment page
    if (!isSubscribed && selectedOption.value !== 'auto') {
        (0,_utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__.openPaymentPage)();
        // Reset to auto (original format)
        outputFormatDesktop.value = 'auto';
        if (outputFormatSelect) {
            outputFormatSelect.value = 'auto';
        }
        // Also reset user preferences
        userPreferences.outputFormat = 'auto';
        userPreferences.originalFormat = true;
        await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
        return;
    }
    // Update preferences
    userPreferences.outputFormat = outputFormatDesktop.value;
    userPreferences.originalFormat = outputFormatDesktop.value === 'auto';
    await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
    // Sync with header dropdown
    if (outputFormatSelect) {
        outputFormatSelect.value = outputFormatDesktop.value;
    }
}
/**
 * Handle force format checkbox change
 */
async function handleForceFormatChange() {
    forceFormat = forceFormatCheckbox.checked;
    userPreferences.forceFormat = forceFormat;
    await (0,_utils_storage__WEBPACK_IMPORTED_MODULE_1__.savePreferences)(userPreferences);
    updateDataPreview();
}
/**
 * Convert all the data using selected formats
 */
function convertParsedData() {
    if (!parsedData) {
        throw new Error('No data to convert');
    }
    // Create a deep copy of the parsed data
    const convertedData = {
        headers: [...parsedData.headers],
        rows: parsedData.rows.map(row => [...row]),
        columns: parsedData.columns.map(col => ({ ...col })),
        hasHeaders: parsedData.hasHeaders
    };
    // Convert each cell based on its column's format
    convertedData.rows = convertedData.rows.map(row => {
        return row.map((cell, colIndex) => {
            const column = parsedData.columns[colIndex];
            if (column && column.selectedFormat) {
                const originalFormat = column.selectedFormat;
                // Determine target format
                if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === originalFormat)) {
                    const targetFormat = column.targetFormat || userPreferences.dateFormat;
                    const convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertDate)(cell, originalFormat, targetFormat);
                    // Use converted value only if it's valid or force format is enabled
                    if (forceFormat || convertedValue !== cell) {
                        return convertedValue;
                    }
                }
                else if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === originalFormat)) {
                    const targetFormat = column.targetFormat || userPreferences.numberFormat;
                    const convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertNumber)(cell, originalFormat, targetFormat);
                    // Use converted value only if it's valid or force format is enabled
                    if (forceFormat || convertedValue !== cell) {
                        return convertedValue;
                    }
                }
            }
            // Return original cell if no conversion applied
            return cell;
        });
    });
    return convertedData;
}
/**
 * Format data for clipboard
 */
function formatDataForClipboard(data) {
    // Always use original format for non-Pro users, regardless of dropdown selection
    if (!isSubscribed) {
        // Use the stored original format type if available
        if (originalFormatType) {
            switch (originalFormatType) {
                case 'json':
                    // Convert tabular data to JSON string
                    const jsonData = [];
                    const headers = data.headers;
                    data.rows.forEach(row => {
                        const rowObj = {};
                        row.forEach((cell, index) => {
                            // Use header as key if available, otherwise use column index
                            const key = data.hasHeaders ? headers[index] : `Column${index + 1}`;
                            rowObj[key] = cell;
                        });
                        jsonData.push(rowObj);
                    });
                    return JSON.stringify(jsonData, null, 2);
                case 'spreadsheet':
                    // Return as tab-delimited for spreadsheet compatibility
                    return formatDataForOutput(data, '\t');
                case 'tsv':
                    return formatDataForOutput(data, '\t');
                case 'csv':
                    return formatDataForOutput(data, ',');
                case 'ssv':
                    return formatDataForOutput(data, ';');
                case 'psv':
                    return formatDataForOutput(data, '|');
            }
        }
        // Fallback to delimiter detection if originalFormatType is not available
        const originalDelimiter = detectOriginalDelimiter(lastClipboardText || '');
        if (originalDelimiter) {
            return formatDataForOutput(data, originalDelimiter);
        }
        // Default to comma if original delimiter can't be detected
        return formatDataForOutput(data, ',');
    }
    // For Pro users, respect the output format preference
    // Special handling for JSON format
    if (userPreferences.outputFormat === 'json') {
        // Convert tabular data to JSON string
        const jsonData = [];
        const headers = data.headers;
        data.rows.forEach(row => {
            const rowObj = {};
            row.forEach((cell, index) => {
                // Use header as key if available, otherwise use column index
                const key = data.hasHeaders ? headers[index] : `Column${index + 1}`;
                rowObj[key] = cell;
            });
            jsonData.push(rowObj);
        });
        return JSON.stringify(jsonData, null, 2);
    }
    // If originalFormat is true, attempt to maintain the original format
    if (userPreferences.originalFormat) {
        // Use the stored original format type if available
        if (originalFormatType) {
            switch (originalFormatType) {
                case 'json':
                    // Convert tabular data to JSON string
                    const jsonData = [];
                    const headers = data.headers;
                    data.rows.forEach(row => {
                        const rowObj = {};
                        row.forEach((cell, index) => {
                            // Use header as key if available, otherwise use column index
                            const key = data.hasHeaders ? headers[index] : `Column${index + 1}`;
                            rowObj[key] = cell;
                        });
                        jsonData.push(rowObj);
                    });
                    return JSON.stringify(jsonData, null, 2);
                case 'spreadsheet':
                    // Return as tab-delimited for spreadsheet compatibility
                    return formatDataForOutput(data, '\t');
                case 'tsv':
                    return formatDataForOutput(data, '\t');
                case 'csv':
                    return formatDataForOutput(data, ',');
                case 'ssv':
                    return formatDataForOutput(data, ';');
                case 'psv':
                    return formatDataForOutput(data, '|');
            }
        }
        // Fallback to delimiter detection if originalFormatType is not available
        const originalDelimiter = detectOriginalDelimiter(lastClipboardText || '');
        if (originalDelimiter) {
            return formatDataForOutput(data, originalDelimiter);
        }
    }
    // Determine the delimiter based on user preference
    let delimiter = ',';
    switch (userPreferences.outputFormat) {
        case 'tab':
            delimiter = '\t';
            break;
        case 'comma':
            delimiter = ',';
            break;
        case 'semicolon':
            delimiter = ';';
            break;
        case 'pipe':
            delimiter = '|';
            break;
        case 'auto':
        default:
            // Auto-detect based on the original data
            // Check for commas in the data to determine if we should use tabs
            const hasCommasInData = data.rows.some(row => row.some(cell => cell.includes(',')));
            if (hasCommasInData) {
                delimiter = '\t'; // Use tabs if data contains commas
            }
            else {
                delimiter = ','; // Default to comma
            }
            break;
    }
    return formatDataForOutput(data, delimiter);
}
/**
 * Detect the original delimiter used in the input data
 */
function detectOriginalDelimiter(text) {
    if (!text)
        return null;
    const lines = text.split('\n');
    if (lines.length === 0)
        return null;
    // Count occurrences of potential delimiters in the first few lines
    const delimiters = [',', '\t', ';', '|'];
    const counts = {};
    delimiters.forEach(d => counts[d] = 0);
    // Check first 5 lines at most
    const linesToCheck = Math.min(lines.length, 5);
    for (let i = 0; i < linesToCheck; i++) {
        delimiters.forEach(d => {
            counts[d] += (lines[i].match(new RegExp(`\\${d}`, 'g')) || []).length;
        });
    }
    // Find the delimiter with the most consistent count per line
    let bestDelimiter = null;
    let bestScore = 0;
    delimiters.forEach(d => {
        const avgCount = counts[d] / linesToCheck;
        if (avgCount > bestScore) {
            bestScore = avgCount;
            bestDelimiter = d;
        }
    });
    return bestDelimiter;
}
/**
 * Show an error message
 */
function showError(message) {
    // Log to console too for debugging
    console.error(`Error message: ${message}`);
    // Create a toast notification element
    const toast = document.createElement('div');
    toast.className = 'error-toast';
    toast.textContent = message;
    // Add to body
    document.body.appendChild(toast);
    // Trigger animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    // Remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}
/**
 * Show a success message
 */
function showSuccess(message) {
    // Create a toast notification element
    const toast = document.createElement('div');
    toast.className = 'success-toast';
    toast.textContent = message;
    // Add to body
    document.body.appendChild(toast);
    // Trigger animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    // Remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}
// Helper functions for formatting examples
function formatDate(date, format) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    // Pad with leading zeros
    const dayStr = day < 10 ? `0${day}` : `${day}`;
    const monthStr = month < 10 ? `0${month}` : `${month}`;
    // Handle different output formats
    if (format === 'MM/DD/YYYY') {
        return `${monthStr}/${dayStr}/${year}`;
    }
    else if (format === 'DD/MM/YYYY') {
        return `${dayStr}/${monthStr}/${year}`;
    }
    else if (format === 'YYYY/MM/DD') {
        return `${year}/${monthStr}/${dayStr}`;
    }
    else if (format === 'MM-DD-YYYY') {
        return `${monthStr}-${dayStr}-${year}`;
    }
    else if (format === 'DD-MM-YYYY') {
        return `${dayStr}-${monthStr}-${year}`;
    }
    else if (format === 'YYYY-MM-DD') {
        return `${year}-${monthStr}-${dayStr}`;
    }
    else if (format === 'DD.MM.YYYY') {
        return `${dayStr}.${monthStr}.${year}`;
    }
    else if (format === 'YYYY.MM.DD') {
        return `${year}.${monthStr}.${dayStr}`;
    }
    else if (format === 'MMMM DD, YYYY') {
        return `${MONTH_NAMES[month - 1]} ${dayStr}, ${year}`;
    }
    else if (format === 'DD MMMM YYYY') {
        return `${dayStr} ${MONTH_NAMES[month - 1]} ${year}`;
    }
    else if (format === 'MMM DD') {
        return `${MONTH_ABBRS[month - 1]} ${dayStr}`;
    }
    else if (format === 'MMM DD YYYY') {
        return `${MONTH_ABBRS[month - 1]} ${dayStr} ${year}`;
    }
    else if (format === 'DD MMM') {
        return `${dayStr} ${MONTH_ABBRS[month - 1]}`;
    }
    else if (format === 'DD MMM YYYY') {
        return `${dayStr} ${MONTH_ABBRS[month - 1]} ${year}`;
    }
    else if (format === 'YYYY MMM') {
        return `${year} ${MONTH_ABBRS[month - 1]}`;
    }
    else if (format === 'YYYY') {
        return `${year}`;
    }
    else if (format === 'unix_timestamp') {
        return Math.floor(date.getTime() / 1000).toString();
    }
    // Default to ISO format
    return `${year}-${monthStr}-${dayStr}`;
}
function formatNumber(num, format) {
    // Get decimal places - copied from formatDetector.ts
    const getDecimalPlaces = (n) => {
        const match = n.toString().match(/(?:\.(\d+))?$/);
        return match && match[1] ? match[1].length : 0;
    };
    // Handle different output formats
    if (format === 'comma_decimal_point') {
        // 1,234.56 format
        return num.toLocaleString('en-US', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        });
    }
    else if (format === 'point_decimal_comma') {
        // 1.234,56 format
        return num.toLocaleString('de-DE', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        });
    }
    else if (format === 'space_decimal_point') {
        // 1 234.56 format
        return num.toLocaleString('en-US', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        }).replace(/,/g, ' ');
    }
    else if (format === 'space_decimal_comma') {
        // 1 234,56 format
        return num.toLocaleString('de-DE', {
            minimumFractionDigits: getDecimalPlaces(num),
            maximumFractionDigits: getDecimalPlaces(num)
        }).replace(/\./g, ' ');
    }
    else if (format === 'no_separator_decimal_point') {
        // 1234.56 format
        return num.toFixed(getDecimalPlaces(num));
    }
    else if (format === 'no_separator_decimal_comma') {
        // 1234,56 format
        return num.toFixed(getDecimalPlaces(num)).replace('.', ',');
    }
    else if (format === 'integer') {
        // 1234 format
        return Math.round(num).toString();
    }
    // Default to standard format
    return num.toString();
}
/**
 * Handle subscription button click
 */
async function handleSubscriptionButtonClick() {
    (0,_utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__.openPaymentPage)();
    // Update subscription status after potential payment
    setTimeout(async () => {
        await updateSubscriptionStatus();
    }, 1000);
}
/**
 * Update subscription button text based on user's subscription status
 */
async function updateSubscriptionStatus() {
    // In development mode, we might use the override
    if (isDevelopmentMode && devModeSubscriptionOverride !== null) {
        isSubscribed = devModeSubscriptionOverride;
    }
    else {
        // Otherwise check the actual subscription status
        const userStatus = await (0,_utils_extPayHandler__WEBPACK_IMPORTED_MODULE_2__.checkUserStatus)();
        isSubscribed = userStatus.paid;
    }
    if (isSubscribed) {
        subscriptionText.textContent = 'Manage Subscription';
        subscriptionBtn.classList.add('subscribed');
    }
    else {
        subscriptionText.textContent = 'Subscribe';
        subscriptionBtn.classList.remove('subscribed');
    }
    // Update Pro features
    updateProFeatureState(exportBtn, isSubscribed);
    updateProFeatureState(outputFormatSelect, isSubscribed);
    // Update output format options
    updateOutputFormatOptions();
}
/**
 * Update the state of Pro features based on subscription status
 */
function updateProFeatureState(element, isSubscribed) {
    if (!element)
        return;
    if (isSubscribed) {
        element.classList.remove('pro-feature-disabled');
        element.classList.add('pro-feature-enabled');
        // If it's a button, make sure it's fully interactive
        if (element instanceof HTMLButtonElement) {
            element.disabled = false;
        }
        // If it's a select element, make it interactive
        if (element instanceof HTMLSelectElement) {
            element.disabled = false;
        }
    }
    else {
        element.classList.add('pro-feature-disabled');
        element.classList.remove('pro-feature-enabled');
        // If it's a button that should be disabled for non-subscribers
        if (element instanceof HTMLButtonElement && element.id === 'exportBtn') {
            // Don't set disabled=true as we still want the click event, but make it visually disabled
            element.setAttribute('data-disabled', 'true');
        }
        // If it's a select element, make it look disabled but still clickable
        if (element instanceof HTMLSelectElement) {
            element.disabled = false; // Keep it enabled so the click event works
        }
    }
}
/**
 * Start monitoring the clipboard for changes
 */
function startClipboardMonitoring() {
    // Don't start monitoring if we already have data
    if (parsedData !== null) {
        return;
    }
    // Clear any existing interval
    if (clipboardMonitorInterval !== null) {
        window.clearInterval(clipboardMonitorInterval);
    }
    // Show the clipboard monitoring indicator
    document.querySelector('.loading-indicator.clipboard-monitor')?.classList.add('active');
    // Start monitoring the clipboard every 500ms
    clipboardMonitorInterval = window.setInterval(async () => {
        // Only attempt to read the clipboard if we don't have data yet
        if (parsedData === null) {
            const clipboardResult = await readClipboard();
            // Check if the clipboard text has changed and is not empty
            if (clipboardResult && clipboardResult.text !== lastClipboardText && clipboardResult.text.trim().length > 0) {
                lastClipboardText = clipboardResult.text;
                processClipboardData(clipboardResult.text, clipboardResult.isSpreadsheetData);
                // Once we have data, stop monitoring
                stopClipboardMonitoring();
            }
        }
        else {
            // We already have data, stop monitoring
            stopClipboardMonitoring();
        }
    }, 500);
}
/**
 * Stop monitoring the clipboard
 */
function stopClipboardMonitoring() {
    if (clipboardMonitorInterval !== null) {
        window.clearInterval(clipboardMonitorInterval);
        clipboardMonitorInterval = null;
    }
    // Hide the clipboard monitoring indicator
    document.querySelector('.loading-indicator.clipboard-monitor')?.classList.remove('active');
}
/**
 * Add CSS styles for Pro features and export modal
 */
function addProFeatureStyles() {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
		/* Output format container styling */
		.output-format-container {
			display: flex;
			align-items: center;
			margin: 0 10px;
		}
		
		.output-format-label {
			margin-right: 5px;
			font-size: 14px;
		}
		
		.output-format-select {
			padding: 4px 8px;
			border-radius: 4px;
			border: 1px solid #ccc;
			font-size: 14px;
		}
		
		/* Action buttons container */
		.popup-actions {
			display: flex;
			justify-content: center;
			align-items: center;
			margin: 15px 0;
			flex-wrap: wrap;
		}
		
		/* Pro feature styling */
		.pro-feature-disabled {
			opacity: 0.7;
			position: relative;
			cursor: pointer;
		}
		
		.pro-feature-disabled::after {
			content: "PRO";
			position: absolute;
			top: -8px;
			right: -8px;
			background-color: #ffab00;
			color: #fff;
			font-size: 9px;
			font-weight: bold;
			padding: 2px 4px;
			border-radius: 4px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.2);
		}
		
		select.pro-feature-disabled {
			background-color: #f5f5f5;
			border-color: #ddd;
		}
		
		select.pro-feature-disabled:hover {
			border-color: #999;
		}
		
		option.pro-option {
			color: #999;
			background-color: #f5f5f5;
		}
		
		button.pro-feature-disabled {
			background-color: #f5f5f5;
			border-color: #ddd;
			color: #666;
			pointer-events: all;
		}
		
		button.pro-feature-disabled:hover {
			background-color: #e9e9e9;
			border-color: #bbb;
		}
		
		.pro-feature-enabled {
			position: relative;
		}
		
		.pro-feature-enabled::after {
			content: "PRO";
			position: absolute;
			top: -8px;
			right: -8px;
			background-color: #4caf50;
			color: #fff;
			font-size: 9px;
			font-weight: bold;
			padding: 2px 4px;
			border-radius: 4px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.2);
		}
		
		/* Export modal styling */
		.export-modal {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0,0,0,0.5);
			display: flex;
			align-items: center;
			justify-content: center;
			z-index: 1000;
		}
		
		.export-modal-content {
			background-color: #fff;
			padding: 20px;
			border-radius: 8px;
			box-shadow: 0 4px 12px rgba(0,0,0,0.2);
			max-width: 400px;
			width: 100%;
		}
		
		.export-modal-content h3 {
			margin-top: 0;
			color: #333;
			font-size: 18px;
			margin-bottom: 15px;
			text-align: center;
		}
		
		.export-format-options {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 10px;
		}
		
		.export-format-option {
			padding: 10px;
			border: 1px solid #ddd;
			border-radius: 4px;
			background-color: #f8f8f8;
			cursor: pointer;
			font-size: 14px;
			text-align: center;
			transition: all 0.2s ease;
		}
		
		.export-format-option:hover {
			background-color: #e0e0e0;
			border-color: #bbb;
		}
		
		.export-format-option.cancel {
			grid-column: span 2;
			background-color: #f5f5f5;
			color: #666;
		}
		
		.export-format-option.cancel:hover {
			background-color: #e0e0e0;
		}
		
		.hidden {
			display: none;
		}
	`;
    document.head.appendChild(styleElement);
}
/**
 * TEST FUNCTIONS
 * These functions are used to verify that the Pro features work correctly
 * They can be called from the browser console during development/testing
 */
/**
 * Run all tests for Pro features
 */
async function testProFeatures() {
    console.group('Testing Pro Features');
    // Test with non-subscribed user
    console.log('Testing as non-subscribed user...');
    await testAsNonSubscriber();
    // Test with subscribed user
    console.log('Testing as subscribed user...');
    await testAsSubscriber();
    console.groupEnd();
    // Reset to actual subscription status
    await updateSubscriptionStatus();
}
/**
 * Test JSON import/export functionality
 */
function testJsonRoundtrip() {
    console.group('Testing JSON Import/Export Roundtrip');
    // Create sample data
    const sampleData = {
        headers: ['Name', 'Date', 'Value', 'Status'],
        rows: [
            ['John Doe', '2023-01-15', '1234.56', 'Active'],
            ['Jane Smith', '2023-02-20', '2345.67', 'Inactive'],
            ['Bob Johnson', '2023-03-25', '3456.78', 'Pending']
        ],
        columns: [],
        hasHeaders: true
    };
    // Add column info
    sampleData.columns = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(sampleData.rows, sampleData.headers);
    console.log('Original sample data:', sampleData);
    // Export to JSON
    console.log('Testing export to JSON...');
    const jsonOutput = exportDataToJson(sampleData);
    console.log('JSON output:', jsonOutput);
    // Import from JSON
    console.log('Testing import from JSON...');
    try {
        const jsonData = JSON.parse(jsonOutput);
        const importedData = importDataFromJson(jsonData);
        // Verify the data matches
        console.log('Imported data:', importedData);
        // Check if headers match
        const headersMatch = JSON.stringify(importedData.headers) === JSON.stringify(sampleData.headers);
        console.log('✓ Headers match:', headersMatch);
        // Check if rows match
        const rowsMatch = importedData.rows.length === sampleData.rows.length;
        console.log('✓ Row count matches:', rowsMatch);
        // Check if values match
        let valuesMatch = true;
        for (let i = 0; i < Math.min(importedData.rows.length, sampleData.rows.length); i++) {
            for (let j = 0; j < Math.min(importedData.rows[i].length, sampleData.rows[i].length); j++) {
                if (importedData.rows[i][j] !== sampleData.rows[i][j]) {
                    console.log(`✗ Value mismatch at [${i}][${j}]:`, `expected "${sampleData.rows[i][j]}", got "${importedData.rows[i][j]}"`);
                    valuesMatch = false;
                }
            }
        }
        console.log('✓ All values match:', valuesMatch);
        // Overall success
        if (headersMatch && rowsMatch && valuesMatch) {
            console.log('✅ JSON roundtrip test PASSED');
        }
        else {
            console.log('❌ JSON roundtrip test FAILED');
        }
    }
    catch (error) {
        console.error('❌ JSON roundtrip test FAILED:', error);
    }
    console.groupEnd();
}
/**
 * Export data to JSON format (test helper)
 */
function exportDataToJson(data) {
    const jsonData = [];
    const headers = data.headers;
    data.rows.forEach(row => {
        const rowObj = {};
        row.forEach((cell, index) => {
            // Use header as key if available, otherwise use column index
            const key = data.hasHeaders ? headers[index] : `Column${index + 1}`;
            rowObj[key] = cell;
        });
        jsonData.push(rowObj);
    });
    return JSON.stringify(jsonData, null, 2);
}
/**
 * Import data from JSON format (test helper)
 */
function importDataFromJson(jsonData) {
    // Get headers from the first object's keys
    const headers = Object.keys(jsonData[0]);
    // Convert JSON to tabular format
    const rows = jsonData.map(item => headers.map(header => {
        const value = item[header];
        // Convert values to strings, handling undefined/null
        if (value === undefined || value === null) {
            return '';
        }
        else if (typeof value === 'object') {
            // Stringify nested objects/arrays
            return JSON.stringify(value);
        }
        else {
            return String(value);
        }
    }));
    return {
        headers,
        rows,
        columns: (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(rows, headers),
        hasHeaders: true
    };
}
/**
 * Test with complex JSON data
 */
function testComplexJsonImport() {
    console.group('Testing Complex JSON Import');
    // Create sample data with nested objects and arrays
    const complexJsonData = [
        {
            "name": "John Doe",
            "date": "2023-01-15",
            "value": 1234.56,
            "status": "Active",
            "tags": ["important", "customer"],
            "metadata": { "region": "North", "priority": "High" }
        },
        {
            "name": "Jane Smith",
            "date": "2023-02-20",
            "value": 2345.67,
            "status": "Inactive",
            "tags": ["archived"],
            "metadata": { "region": "South", "priority": "Medium" }
        }
    ];
    console.log('Complex JSON data:', complexJsonData);
    // Convert to string as if it were imported from a file
    const jsonString = JSON.stringify(complexJsonData);
    // Import the data
    try {
        const jsonData = JSON.parse(jsonString);
        const importedData = importDataFromJson(jsonData);
        console.log('Imported complex data:', importedData);
        // Check that complex objects were properly stringified
        const hasStringifiedObjects = importedData.rows.some(row => row.some(cell => cell.startsWith('[') || cell.startsWith('{')));
        console.log('✓ Has properly stringified objects/arrays:', hasStringifiedObjects);
        // Check array values
        const tagsColumnIndex = importedData.headers.indexOf('tags');
        if (tagsColumnIndex >= 0) {
            console.log('✓ Tags column found at index:', tagsColumnIndex);
            console.log('Sample tags value:', importedData.rows[0][tagsColumnIndex]);
        }
        // Check object values
        const metadataColumnIndex = importedData.headers.indexOf('metadata');
        if (metadataColumnIndex >= 0) {
            console.log('✓ Metadata column found at index:', metadataColumnIndex);
            console.log('Sample metadata value:', importedData.rows[0][metadataColumnIndex]);
        }
        console.log('✅ Complex JSON import test PASSED');
    }
    catch (error) {
        console.error('❌ Complex JSON import test FAILED:', error);
    }
    console.groupEnd();
}
/**
 * Test Pro features with a non-subscribed user
 */
async function testAsNonSubscriber() {
    // Force non-subscribed state
    const originalStatus = isSubscribed;
    isSubscribed = false;
    updateProFeatureState(outputFormatSelect, isSubscribed);
    updateProFeatureState(exportBtn, isSubscribed);
    console.group('Non-subscriber Tests');
    // Test 1: Output format selection should be disabled
    console.log('Test 1: Output format selector should be disabled');
    console.log('✓ Output format has pro-feature-disabled class:', outputFormatSelect.classList.contains('pro-feature-disabled'));
    // Test 2: Default behavior should maintain original format
    console.log('Test 2: Default behavior should use original format');
    if (parsedData) {
        const testData = { ...parsedData };
        const clipText = formatDataForClipboard(testData);
        const originalDelimiter = detectOriginalDelimiter(lastClipboardText || '');
        console.log('✓ Original delimiter detected:', originalDelimiter);
        console.log('✓ Output maintains original format:', clipText.includes(originalDelimiter || ','));
    }
    else {
        console.log('⚠️ No data available for testing, skipping format test');
    }
    // Test 3: Export button should be disabled
    console.log('Test 3: Export button should be disabled');
    console.log('✓ Export button has pro-feature-disabled class:', exportBtn.classList.contains('pro-feature-disabled'));
    // Simulate clicking export button
    console.log('Simulating export button click (should redirect to payment page)');
    // Log the function that would be called
    console.log('✓ Would call: openPaymentPage()');
    console.groupEnd();
    // Reset original status
    isSubscribed = originalStatus;
}
/**
 * Test Pro features with a subscribed user
 */
async function testAsSubscriber() {
    // Force subscribed state
    const originalStatus = isSubscribed;
    isSubscribed = true;
    updateProFeatureState(outputFormatSelect, isSubscribed);
    updateProFeatureState(exportBtn, isSubscribed);
    console.group('Subscriber Tests');
    // Test 1: Output format selection should be enabled
    console.log('Test 1: Output format selector should be enabled');
    console.log('✓ Output format has pro-feature-enabled class:', outputFormatSelect.classList.contains('pro-feature-enabled'));
    // Test 2: Changing output format should update preferences
    console.log('Test 2: Changing output format should work');
    const originalFormat = userPreferences.outputFormat;
    // Log the formats that would be applied
    const formats = ['tab', 'comma', 'semicolon', 'pipe', 'auto'];
    formats.forEach(format => {
        console.log(`✓ When selecting ${format}, would set userPreferences.outputFormat to "${format}"`);
    });
    // Test 3: Export button should be enabled
    console.log('Test 3: Export button should be enabled');
    console.log('✓ Export button has pro-feature-enabled class:', exportBtn.classList.contains('pro-feature-enabled'));
    // Test 4: Export options should work
    console.log('Test 4: Export options should appear when clicking export');
    console.log('✓ Would show export options modal with CSV, TSV, Excel, and JSON options');
    // Log export function simulations
    if (parsedData) {
        console.log('Sample export operations:');
        console.log('✓ CSV export would create file with comma delimiter');
        console.log('✓ TSV export would create file with tab delimiter');
        console.log('✓ Excel export would create CSV file optimized for Excel');
        console.log('✓ JSON export would create structured JSON with headers as keys');
    }
    else {
        console.log('⚠️ No data available for export testing');
    }
    console.groupEnd();
    // Reset original status
    isSubscribed = originalStatus;
}
/**
 * Test data parsing and conversion with sample data
 */
function testWithSampleData() {
    console.group('Testing with Sample Data');
    // Sample data for testing
    const sampleCSV = `Date,Value,Name
2023-01-15,1234.56,Test Item 1
2023/02/20,2345.67,Test Item 2
01/25/2023,3456.78,Test Item 3`;
    // Parse the sample data without prompting
    console.log('Parsing sample data...');
    const testData = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.parseTabularData)(sampleCSV, false);
    if (testData) {
        console.log('✓ Sample data parsed:', testData);
        // Test format detection
        console.log('Testing format detection...');
        if (testData.columns.length >= 2) {
            const dateColumn = testData.columns[0];
            const valueColumn = testData.columns[1];
            console.log('✓ Date formats detected:', dateColumn.possibleFormats);
            console.log('✓ Number formats detected:', valueColumn.possibleFormats);
        }
        // Test output formatting with different delimiters
        console.log('Testing output formatting...');
        const csvOutput = formatDataForOutput(testData, ',');
        const tsvOutput = formatDataForOutput(testData, '\t');
        const semicolonOutput = formatDataForOutput(testData, ';');
        console.log('✓ CSV output:', csvOutput.substring(0, 50) + '...');
        console.log('✓ TSV output:', tsvOutput.substring(0, 50) + '...');
        console.log('✓ Semicolon output:', semicolonOutput.substring(0, 50) + '...');
    }
    else {
        console.log('✗ Failed to parse sample data');
    }
    console.groupEnd();
}
/**
 * Test all features together
 */
async function runAllTests() {
    console.group('Running All Tests');
    // Test Pro features
    await testProFeatures();
    // Test with sample data
    testWithSampleData();
    // Test JSON roundtrip
    testJsonRoundtrip();
    // Test complex JSON import
    testComplexJsonImport();
    // Test JSON clipboard roundtrip
    testJsonClipboardRoundtrip();
    // Test spreadsheet import
    testSpreadsheetImport();
    console.log('All tests completed!');
    console.groupEnd();
}
// Expose test functions to window object for console access
window.testProFeatures = testProFeatures;
window.testAsNonSubscriber = testAsNonSubscriber;
window.testAsSubscriber = testAsSubscriber;
window.testWithSampleData = testWithSampleData;
window.runAllTests = runAllTests;
window.testJsonRoundtrip = testJsonRoundtrip;
window.testComplexJsonImport = testComplexJsonImport;
window.testJsonClipboardRoundtrip = testJsonClipboardRoundtrip;
window.testSpreadsheetImport = testSpreadsheetImport;
/**
 * Create file import option in the no data section
 */
function createFileImportOption() {
    const noDataSection = document.getElementById('noDataSection');
    // Create file import container
    const fileImportContainer = document.createElement('div');
    fileImportContainer.className = 'file-import-container';
    // Create file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.id = 'fileInput';
    fileInput.accept = '.csv,.tsv,.txt,.json';
    fileInput.style.display = 'none';
    // Create file import button
    const fileImportButton = document.createElement('button');
    fileImportButton.className = 'file-import-button';
    fileImportButton.textContent = 'Import from file';
    fileImportButton.addEventListener('click', () => {
        fileInput.click();
    });
    // Add event listener for file input
    fileInput.addEventListener('change', handleFileImport);
    // Create file import text
    const fileImportText = document.createElement('p');
    fileImportText.textContent = 'Or import data from a file';
    // Add elements to the container
    fileImportContainer.appendChild(fileImportText);
    fileImportContainer.appendChild(fileImportButton);
    fileImportContainer.appendChild(fileInput);
    // Add container to the no data section
    noDataSection.appendChild(fileImportContainer);
}
/**
 * Handle file import
 */
async function handleFileImport(event) {
    const fileInput = event.target;
    const file = fileInput.files?.[0];
    if (!file) {
        return;
    }
    try {
        // Show loading indicator
        document.querySelector('.loading-indicator')?.classList.add('active');
        // Read file content
        const content = await readFile(file);
        // Process file data
        processFileData(content, file.name);
        // Reset file input
        fileInput.value = '';
        // Hide loading indicator
        document.querySelector('.loading-indicator')?.classList.remove('active');
    }
    catch (error) {
        console.error('Failed to read file:', error);
        showError('Failed to read file. Make sure it is a valid tabular data file.');
        document.querySelector('.loading-indicator')?.classList.remove('active');
    }
}
/**
 * Read file content
 */
async function readFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            resolve(reader.result);
        };
        reader.onerror = () => {
            reject(new Error('Failed to read file'));
        };
        reader.readAsText(file);
    });
}
/**
 * Process file data
 */
function processFileData(content, fileName) {
    try {
        // Store the original content
        lastClipboardText = content;
        // Special handling for JSON files
        if (fileName.toLowerCase().endsWith('.json')) {
            // Set the original format type to JSON
            originalFormatType = 'json';
            try {
                const jsonData = JSON.parse(content);
                // Check if it's an array of objects (our standard export format)
                if (Array.isArray(jsonData) && jsonData.length > 0 && typeof jsonData[0] === 'object') {
                    // Get headers from the first object's keys
                    const headers = Object.keys(jsonData[0]);
                    // Check if all items have the same structure
                    const allItemsValid = jsonData.every(item => typeof item === 'object' &&
                        item !== null &&
                        // Ensure each item has at least some of the same keys
                        headers.some(header => header in item));
                    if (!allItemsValid) {
                        throw new Error('JSON array contains items with inconsistent structure.');
                    }
                    // Convert JSON to tabular format
                    const rows = jsonData.map(item => headers.map(header => {
                        const value = item[header];
                        // Convert values to strings, handling undefined/null
                        if (value === undefined || value === null) {
                            return '';
                        }
                        else if (typeof value === 'object') {
                            // Stringify nested objects/arrays
                            return JSON.stringify(value);
                        }
                        else {
                            return String(value);
                        }
                    }));
                    parsedData = {
                        headers,
                        rows,
                        columns: (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(rows, headers),
                        hasHeaders: true
                    };
                    // Log success
                    console.log('Successfully imported JSON with', rows.length, 'rows and', headers.length, 'columns');
                }
                else if (Array.isArray(jsonData)) {
                    // Handle array of arrays format (alternative JSON format)
                    if (jsonData.length > 0 && Array.isArray(jsonData[0])) {
                        // Assume first row is headers if all elements are strings
                        const hasHeaders = jsonData[0].every(item => typeof item === 'string');
                        const headers = hasHeaders
                            ? jsonData[0].map(String)
                            : jsonData[0].map((_, i) => `Column ${i + 1}`);
                        const rows = hasHeaders ? jsonData.slice(1) : jsonData;
                        // Convert all values to strings
                        const stringRows = rows.map(row => row.map((cell) => {
                            if (cell === null || cell === undefined) {
                                return '';
                            }
                            else if (typeof cell === 'object') {
                                return JSON.stringify(cell);
                            }
                            else {
                                return String(cell);
                            }
                        }));
                        parsedData = {
                            headers,
                            rows: stringRows,
                            columns: (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(stringRows, headers),
                            hasHeaders
                        };
                        console.log('Successfully imported JSON array format with', stringRows.length, 'rows');
                    }
                    else {
                        throw new Error('Invalid JSON format. Expected array of objects or array of arrays.');
                    }
                }
                else {
                    throw new Error('Invalid JSON format. Expected array of objects or array of arrays.');
                }
            }
            catch (jsonError) {
                console.error('JSON parsing error:', jsonError);
                console.error(`Full JSON error details: ${JSON.stringify(jsonError, Object.getOwnPropertyNames(jsonError))}`);
                const errorMessage = jsonError instanceof Error ? jsonError.message : 'Unknown JSON parsing error';
                showError(`Invalid JSON format: ${errorMessage}`);
                return;
            }
        }
        else {
            // Detect format based on file extension and content
            if (fileName.toLowerCase().endsWith('.csv')) {
                originalFormatType = 'csv';
            }
            else if (fileName.toLowerCase().endsWith('.tsv')) {
                originalFormatType = 'tsv';
            }
            else if (fileName.toLowerCase().endsWith('.txt')) {
                // Try to detect delimiter for txt files
                if (content.includes('\t')) {
                    originalFormatType = 'tsv';
                }
                else if (content.includes(',')) {
                    originalFormatType = 'csv';
                }
                else if (content.includes(';')) {
                    originalFormatType = 'ssv';
                }
                else if (content.includes('|')) {
                    originalFormatType = 'psv';
                }
                else {
                    originalFormatType = null;
                }
            }
            else {
                // Default to null for unknown formats
                originalFormatType = null;
            }
            // For CSV, TSV, and other text formats, use the enhanced parser with prompting
            (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.parseTabularData)(content, true, (result) => {
                if (result) {
                    parsedData = result;
                    // Update UI
                    formatDetectionSection.classList.remove('hidden');
                    noDataSection.classList.add('hidden');
                    // Display data preview
                    updateDataPreview();
                }
                else {
                    // This happens if the user cancels the delimiter prompt
                    showError('Failed to process file data. Please try again with a different file.');
                }
            });
            return; // Early return because we're using a callback
        }
        // Update UI (only for JSON files or parsing without callback)
        formatDetectionSection.classList.remove('hidden');
        noDataSection.classList.add('hidden');
        // Display data preview
        updateDataPreview();
        // Stop monitoring clipboard as we now have data
        stopClipboardMonitoring();
    }
    catch (error) {
        console.error('Failed to process file data:', error);
        console.error(`Full file processing error details: ${JSON.stringify(error, Object.getOwnPropertyNames(error))}`);
        showError('Failed to process file data. Make sure it is valid tabular data.');
    }
}
/**
 * Set up drag and drop support
 */
function setupDragAndDrop() {
    const dropZone = document.getElementById('noDataSection');
    // Add drag and drop event listeners
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.add('drag-over');
    });
    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.remove('drag-over');
    });
    dropZone.addEventListener('drop', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.remove('drag-over');
        const files = e.dataTransfer?.files;
        if (!files || files.length === 0) {
            return;
        }
        const file = files[0];
        try {
            // Show loading indicator
            document.querySelector('.loading-indicator')?.classList.add('active');
            // Read file content
            const content = await readFile(file);
            // Process file data
            processFileData(content, file.name);
            // Hide loading indicator
            document.querySelector('.loading-indicator')?.classList.remove('active');
        }
        catch (error) {
            console.error('Failed to read dropped file:', error);
            showError('Failed to read dropped file. Make sure it is a valid tabular data file.');
            document.querySelector('.loading-indicator')?.classList.remove('active');
        }
    });
}
/**
 * Test JSON clipboard export/import roundtrip
 */
function testJsonClipboardRoundtrip() {
    console.group('Testing JSON Clipboard Export/Import Roundtrip');
    // Create sample data
    const sampleData = {
        headers: ['Name', 'Date', 'Value', 'Status'],
        rows: [
            ['John Doe', '2023-01-15', '1234.56', 'Active'],
            ['Jane Smith', '2023-02-20', '2345.67', 'Inactive'],
            ['Bob Johnson', '2023-03-25', '3456.78', 'Pending']
        ],
        columns: [],
        hasHeaders: true
    };
    // Add column info
    sampleData.columns = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.analyzeColumns)(sampleData.rows, sampleData.headers);
    console.log('Original sample data:', sampleData);
    // Simulate export to clipboard in JSON format
    console.log('Testing export as JSON to clipboard...');
    // Force JSON format
    const originalOutputFormat = userPreferences.outputFormat;
    userPreferences.outputFormat = 'json';
    // Get JSON string that would be copied to clipboard
    const jsonClipboardText = formatDataForClipboard(sampleData);
    console.log('JSON clipboard content:', jsonClipboardText);
    // Now simulate clipboard import by parsing this JSON
    console.log('Testing import from JSON clipboard...');
    try {
        // Use parseTabularData directly as it now includes JSON detection
        const importedData = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.parseTabularData)(jsonClipboardText);
        if (!importedData) {
            console.error('❌ JSON clipboard roundtrip test FAILED: Import returned null');
            console.groupEnd();
            return;
        }
        // Verify the data matches
        console.log('Imported data:', importedData);
        // Check if headers match
        const headersMatch = JSON.stringify(importedData.headers) === JSON.stringify(sampleData.headers);
        console.log('✓ Headers match:', headersMatch);
        // Check if rows match
        const rowsMatch = importedData.rows.length === sampleData.rows.length;
        console.log('✓ Row count matches:', rowsMatch);
        // Check if values match
        let valuesMatch = true;
        for (let i = 0; i < Math.min(importedData.rows.length, sampleData.rows.length); i++) {
            for (let j = 0; j < Math.min(importedData.rows[i].length, sampleData.rows[i].length); j++) {
                if (importedData.rows[i][j] !== sampleData.rows[i][j]) {
                    console.log(`✗ Value mismatch at [${i}][${j}]:`, `expected "${sampleData.rows[i][j]}", got "${importedData.rows[i][j]}"`);
                    valuesMatch = false;
                }
            }
        }
        console.log('✓ All values match:', valuesMatch);
        // Overall success
        if (headersMatch && rowsMatch && valuesMatch) {
            console.log('✅ JSON clipboard roundtrip test PASSED');
        }
        else {
            console.log('❌ JSON clipboard roundtrip test FAILED');
        }
    }
    catch (error) {
        console.error('❌ JSON clipboard roundtrip test FAILED:', error);
    }
    finally {
        // Restore original output format
        userPreferences.outputFormat = originalOutputFormat;
    }
    console.groupEnd();
}
/**
 * Test spreadsheet clipboard data import
 */
function testSpreadsheetImport() {
    console.group('Testing Spreadsheet Clipboard Import');
    // Sample data in the format that would come from spreadsheet apps
    const sampleSheetData = [
        // Google Sheets format (tab-delimited)
        {
            name: 'Google Sheets',
            data: 'Name\tDate\tValue\tStatus\nJohn Doe\t2023-01-15\t1234.56\tActive\nJane Smith\t2023-02-20\t2345.67\tInactive'
        },
        // Excel format (tab-delimited with different line endings)
        {
            name: 'Excel',
            data: 'Name\tDate\tValue\tStatus\r\nJohn Doe\t2023-01-15\t$1,234.56\tActive\r\nJane Smith\t2023-02-20\t$2,345.67\tInactive'
        },
        // Data with bracket characters that might be confused with JSON
        {
            name: 'Confusing Data',
            data: 'Name\tTags\tNotes\nJohn Doe\t[tag1, tag2]\t{see notes}\nJane Smith\t[tag3]\t{important: follow up}'
        }
    ];
    // Test each format
    for (const sample of sampleSheetData) {
        console.log(`Testing ${sample.name} format...`);
        try {
            // Use parseTabularData directly (the same function used for clipboard detection)
            const importedData = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.parseTabularData)(sample.data);
            if (!importedData) {
                console.error(`❌ ${sample.name} test FAILED: Import returned null`);
                continue;
            }
            // Verify the data structure
            console.log(`✓ ${sample.name} data imported successfully`);
            console.log('Headers:', importedData.headers);
            console.log('Rows:', importedData.rows.length);
            console.log('First row:', importedData.rows[0]);
            // Check if we have reasonable amounts of rows and columns
            const hasSufficientRows = importedData.rows.length > 0;
            const hasSufficientColumns = importedData.headers.length > 1;
            if (hasSufficientRows && hasSufficientColumns) {
                console.log(`✅ ${sample.name} format test PASSED`);
            }
            else {
                console.error(`❌ ${sample.name} test FAILED: Insufficient rows or columns`);
            }
        }
        catch (error) {
            console.error(`❌ ${sample.name} test FAILED:`, error);
        }
    }
    console.log('All spreadsheet format tests completed!');
    console.groupEnd();
}
/**
 * Add input format buttons for this column
 */
function addInputFormatButtons(container, column, columnIndex, targetFormat) {
    if (!column.possibleFormats.length) {
        return;
    }
    // First check if any values already match the target format
    let shouldShowInputFormats = true;
    if (parsedData && targetFormat) {
        // Get the column's data
        const columnData = parsedData.rows.map(row => row[columnIndex]);
        // Check if a significant number of values already match the target format
        let matchingCount = 0;
        for (const cell of columnData) {
            // Try to convert using detected formats and see if output matches the cell
            // This is a simple check - real implementation would use your formatDetector logic
            const mostLikelyFormat = column.possibleFormats[0];
            if (mostLikelyFormat) {
                const isDateFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === mostLikelyFormat.formatKey);
                const isNumberFormat = _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === mostLikelyFormat.formatKey);
                let convertedValue = cell;
                if (isDateFormat) {
                    convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertDate)(cell, mostLikelyFormat.formatKey, targetFormat);
                }
                else if (isNumberFormat) {
                    convertedValue = (0,_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.convertNumber)(cell, mostLikelyFormat.formatKey, targetFormat);
                }
                // If original value matches converted value, count as already matching
                if (cell === convertedValue) {
                    matchingCount++;
                }
            }
        }
    }
    // Create container for format buttons
    const formatButtonsContainer = document.createElement('div');
    formatButtonsContainer.className = 'column-format-buttons';
    // // Add icon and "Input format:" label
    // const formatLabel = document.createElement('div');
    // formatLabel.className = 'format-label';
    // formatLabel.innerHTML = '<span class="format-icon">📥</span> Input format:';
    // formatButtonsContainer.appendChild(formatLabel);
    // Determine if we should show the input formats
    // This is true if we have clear formats or if user has already set a format
    const hasDateFormat = column.possibleFormats.some((format) => _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(df => df.key === format.formatKey));
    const hasNumberFormat = column.possibleFormats.some((format) => _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(nf => nf.key === format.formatKey));
    const hasHighConfidenceFormat = column.possibleFormats.some((format) => format.confidence > 0.7);
    const showFormats = hasDateFormat || hasNumberFormat ||
        hasHighConfidenceFormat || column.selectedFormat;
    // If we should show input formats, proceed
    if (showFormats) {
        // Sort by confidence
        const sortedFormats = [...column.possibleFormats].sort((a, b) => b.confidence - a.confidence);
        // Get most likely format
        const mostLikelyFormat = sortedFormats[0];
        // Add the most likely format button
        if (mostLikelyFormat) {
            addFormatButton(formatButtonsContainer, {
                key: mostLikelyFormat.formatKey,
                name: mostLikelyFormat.formatName
            }, column.selectedFormat || '', (formatKey) => {
                // Set this as the selected format for the column
                if (parsedData && parsedData.columns[columnIndex]) {
                    parsedData.columns[columnIndex].selectedFormat = formatKey || null;
                    updateDataPreview();
                }
            });
            // Select this format if none is selected yet
            if (!column.selectedFormat) {
                column.selectedFormat = mostLikelyFormat.formatKey;
            }
        }
        // Add "..." button if there are more formats
        if (sortedFormats.length > 1) {
            const moreButton = document.createElement('button');
            moreButton.className = 'format-more-button';
            moreButton.textContent = '...';
            moreButton.title = 'Show other possible input formats';
            moreButton.addEventListener('click', (e) => {
                e.stopPropagation();
                // Remove existing dropdowns
                document.querySelectorAll('.format-dropdown').forEach(el => el.remove());
                // Create dropdown menu
                const dropdown = document.createElement('div');
                dropdown.className = 'format-dropdown';
                // Add other formats to dropdown
                sortedFormats.slice(1).forEach(format => {
                    addFormatButton(dropdown, {
                        key: format.formatKey,
                        name: `${format.formatName} (${Math.round(format.confidence * 100)}%)`
                    }, column.selectedFormat || '', (formatKey) => {
                        // Set this as the selected format for the column
                        if (parsedData && parsedData.columns[columnIndex]) {
                            parsedData.columns[columnIndex].selectedFormat = formatKey || null;
                            updateDataPreview();
                        }
                        // Hide the dropdown
                        dropdown.remove();
                    });
                });
                // Position dropdown below button
                const rect = moreButton.getBoundingClientRect();
                dropdown.style.position = 'absolute';
                dropdown.style.top = `${rect.bottom}px`;
                dropdown.style.left = `${rect.left}px`;
                // Add to body
                document.body.appendChild(dropdown);
                // Close dropdown when clicking outside
                const handleClickOutside = (evt) => {
                    if (!dropdown.contains(evt.target)) {
                        dropdown.remove();
                        document.removeEventListener('click', handleClickOutside);
                    }
                };
                // Wait for this click to finish before adding listener
                setTimeout(() => {
                    document.addEventListener('click', handleClickOutside);
                }, 0);
            });
            formatButtonsContainer.appendChild(moreButton);
        }
        // Add the format buttons to the container
        container.appendChild(formatButtonsContainer);
        // If this column might contain years, add the year/integer toggle
        if (column.mightContainYears) {
            addYearIntegerToggle(formatButtonsContainer, column, columnIndex);
        }
    }
}
/**
 * Add a format button to the container
 * @returns The created button element
 */
function addFormatButton(container, format, selectedFormat, onSelect) {
    const formatButton = document.createElement('button');
    formatButton.className = 'column-format-button';
    formatButton.dataset.format = format.key;
    // Set button text to format example
    if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.some(f => f.key === format.key)) {
        formatButton.textContent = format.key === 'unix_timestamp'
            ? 'timestamp'
            : formatDate(new Date(), format.key);
    }
    else if (_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.some(f => f.key === format.key)) {
        formatButton.textContent = formatNumber(1234.56, format.key);
    }
    else {
        formatButton.textContent = format.name;
    }
    formatButton.title = format.name;
    // Mark as selected if it's the current target format
    if (format.key === selectedFormat) {
        formatButton.classList.add('selected');
    }
    // Add click event
    formatButton.addEventListener('click', () => {
        // Update selected button UI
        container.querySelectorAll('.column-format-button').forEach(btn => {
            btn.classList.remove('selected');
        });
        formatButton.classList.add('selected');
        // Call the select handler
        onSelect(format.key);
    });
    container.appendChild(formatButton);
    return formatButton;
}
/**
 * Add a "more" button that shows a dropdown of all formats
 */
function addMoreButton(container, allFormats, visibleFormats, selectedFormat, onSelect) {
    const moreButton = document.createElement('button');
    moreButton.className = 'format-more-button';
    moreButton.textContent = '...';
    moreButton.title = 'Show other possible formats';
    moreButton.addEventListener('click', (e) => {
        e.stopPropagation();
        // Remove existing dropdowns
        document.querySelectorAll('.format-dropdown').forEach(el => el.remove());
        // Create dropdown menu
        const dropdown = document.createElement('div');
        dropdown.className = 'format-dropdown';
        // Get formats not yet visible
        const hiddenFormats = allFormats.filter(format => !visibleFormats.some(visible => visible.key === format.key));
        // Add formats to dropdown
        hiddenFormats.forEach(format => {
            addFormatButton(dropdown, format, selectedFormat, (formatKey) => {
                // Add this format to the visible formats in the container
                const buttonContainer = moreButton.parentElement;
                if (buttonContainer && buttonContainer.classList.contains('column-format-buttons')) {
                    // Create a new button and add it before the more button
                    const newButton = addFormatButton(buttonContainer, format, formatKey, onSelect);
                    // Move the new button before the more button
                    buttonContainer.insertBefore(newButton, moreButton);
                    // Remove if already selected
                    buttonContainer.querySelectorAll('.column-format-button').forEach((btn) => {
                        const button = btn;
                        if (button !== newButton && button.dataset.format === formatKey) {
                            button.remove();
                        }
                    });
                }
                // Close the dropdown
                dropdown.remove();
                // Call the select handler
                onSelect(formatKey);
            });
        });
        // Position the dropdown below the more button
        const moreButtonRect = moreButton.getBoundingClientRect();
        const parentWidth = container ? container.getBoundingClientRect().width : moreButtonRect.width;
        dropdown.style.position = 'absolute';
        dropdown.style.top = `${moreButtonRect.bottom + 5}px`;
        dropdown.style.left = `${moreButtonRect.left}px`;
        dropdown.style.width = `${parentWidth}px`;
        document.body.appendChild(dropdown);
        // Adjust position if needed to keep it within view
        const rect = dropdown.getBoundingClientRect();
        if (rect.right > window.innerWidth) {
            dropdown.style.left = `${window.innerWidth - rect.width - 10}px`;
        }
        // Close dropdown when clicking outside
        const handleClickOutside = (event) => {
            if (!dropdown.contains(event.target) && event.target !== moreButton) {
                dropdown.remove();
                document.removeEventListener('click', handleClickOutside);
            }
        };
        // Use setTimeout to avoid immediate triggering
        setTimeout(() => {
            document.addEventListener('click', handleClickOutside);
        }, 0);
    });
    container.appendChild(moreButton);
}
/**
 * Get relevant date formats based on the detected format
 */
function getRelevantDateFormats(detectedFormat) {
    // For abbreviated month formats, show both abbreviated and full month formats
    if (detectedFormat === 'MMM DD' || detectedFormat === 'DD MMM' ||
        detectedFormat === 'MMM DD YYYY' || detectedFormat === 'DD MMM YYYY' ||
        detectedFormat === 'MMM DD YYYY' || detectedFormat === 'DD MMMM YYYY') {
        // Return both abbreviated and full month formats
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key.includes('MMM') || // Include all abbreviated formats
            f.key === 'MMMM DD, YYYY' || // Include full month formats
            f.key === 'DD MMMM YYYY');
    }
    // For year only, show all date formats as options
    if (detectedFormat === 'YYYY') {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS;
    }
    // For unix timestamp, prefer date formats without time
    if (detectedFormat === 'unix_timestamp') {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS;
    }
    // Group formats by separator type
    if (detectedFormat.includes('/')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key.includes('/'));
    }
    else if (detectedFormat.includes('-')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key.includes('-'));
    }
    else if (detectedFormat.includes('.')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key.includes('.'));
    }
    else if (detectedFormat.includes(' ')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS.filter(f => f.key.includes(' '));
    }
    // Default to all formats
    return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.DATE_FORMATS;
}
/**
 * Get relevant number formats based on the detected format
 */
function getRelevantNumberFormats(detectedFormat) {
    // If using comma as decimal
    if (detectedFormat.includes('decimal_comma')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.filter(f => f.key.includes('decimal_comma'));
    }
    // If using point as decimal
    else if (detectedFormat.includes('decimal_point')) {
        return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.filter(f => f.key.includes('decimal_point'));
    }
    // If integer
    else if (detectedFormat === 'integer') {
        return [_utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS.find(f => f.key === 'integer')];
    }
    // Default to all formats
    return _utils_formatDetector__WEBPACK_IMPORTED_MODULE_0__.NUMBER_FORMATS;
}
/**
 * Add a year/integer toggle for columns that have 4-digit numbers that might be years
 */
function addYearIntegerToggle(container, column, columnIndex) {
    // Check if there's at least one integer format and one year format detected
    const hasIntegerFormat = column.possibleFormats.some((f) => f.formatKey === 'integer');
    const hasYearFormat = column.possibleFormats.some((f) => f.formatKey === 'YYYY');
    if (!hasIntegerFormat || !hasYearFormat) {
        return;
    }
    // Create toggle container
    const toggleContainer = document.createElement('div');
    toggleContainer.className = 'year-integer-toggle';
    // Add label
    const label = document.createElement('span');
    label.className = 'toggle-label';
    label.textContent = '4-digit numbers as:';
    toggleContainer.appendChild(label);
    // Create the toggle buttons
    const integerBtn = document.createElement('button');
    integerBtn.className = 'toggle-btn';
    integerBtn.textContent = 'Integer';
    integerBtn.title = 'Treat 4-digit numbers as integers';
    const yearBtn = document.createElement('button');
    yearBtn.className = 'toggle-btn';
    yearBtn.textContent = 'Year';
    yearBtn.title = 'Treat 4-digit numbers as years';
    // Set initial state based on current selection
    if (column.selectedFormat === 'YYYY') {
        yearBtn.classList.add('active');
    }
    else {
        integerBtn.classList.add('active');
    }
    // Add click handlers
    integerBtn.addEventListener('click', () => {
        integerBtn.classList.add('active');
        yearBtn.classList.remove('active');
        // Update column format to integer
        if (parsedData && parsedData.columns[columnIndex]) {
            parsedData.columns[columnIndex].selectedFormat = 'integer';
            updateDataPreview();
        }
    });
    yearBtn.addEventListener('click', () => {
        yearBtn.classList.add('active');
        integerBtn.classList.remove('active');
        // Update column format to year
        if (parsedData && parsedData.columns[columnIndex]) {
            parsedData.columns[columnIndex].selectedFormat = 'YYYY';
            updateDataPreview();
        }
    });
    // Add buttons to toggle container
    toggleContainer.appendChild(integerBtn);
    toggleContainer.appendChild(yearBtn);
    // Add toggle to main container
    container.appendChild(toggleContainer);
}

})();

/******/ })()
;
//# sourceMappingURL=popup.js.map